'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Plus,
  MoreHorizontal,
  Edit2,
  Trash2,
  Briefcase,
  MapPin,
  DollarSign,
  Users,
  Eye,
  EyeOff,
  Pause,
  Play,
} from 'lucide-react'
import { format } from 'date-fns'
import { es } from 'date-fns/locale'

// Types
type EstatusVacante = 'BORRADOR' | 'PUBLICADA' | 'PAUSADA' | 'CERRADA'
type PrioridadVacante = 'BAJA' | 'MEDIA' | 'ALTA' | 'URGENTE'

interface Vacante {
  id: string
  titulo: string
  descripcion?: string | null
  ubicacion?: string | null
  salarioMin?: number | null
  salarioMax?: number | null
  estatus: EstatusVacante
  prioridad: PrioridadVacante
  createdAt: string
  candidatosCount?: number
  reclutador?: { id: string; name: string | null } | null
}

interface VacantesManagerProps {
  vacantes: Vacante[]
  onCreate: (data: Partial<Vacante>) => void
  onUpdate: (id: string, data: Partial<Vacante>) => void
  onDelete: (id: string) => void
  onSelect: (id: string) => void
  userRole: string
}

// Estatus config
const ESTATUS_CONFIG: Record<EstatusVacante, { label: string; color: string; icon: any }> = {
  BORRADOR: { label: 'Borrador', color: 'bg-slate-500/20 text-slate-400', icon: EyeOff },
  PUBLICADA: { label: 'Publicada', color: 'bg-green-500/20 text-green-400', icon: Eye },
  PAUSADA: { label: 'Pausada', color: 'bg-amber-500/20 text-amber-400', icon: Pause },
  CERRADA: { label: 'Cerrada', color: 'bg-red-500/20 text-red-400', icon: null },
}

// Prioridad config
const PRIORIDAD_CONFIG: Record<PrioridadVacante, { label: string; color: string }> = {
  BAJA: { label: 'Baja', color: 'bg-slate-500/20 text-slate-400' },
  MEDIA: { label: 'Media', color: 'bg-blue-500/20 text-blue-400' },
  ALTA: { label: 'Alta', color: 'bg-amber-500/20 text-amber-400' },
  URGENTE: { label: 'Urgente', color: 'bg-red-500/20 text-red-400' },
}

export function VacantesManager({
  vacantes,
  onCreate,
  onUpdate,
  onDelete,
  onSelect,
  userRole,
}: VacantesManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingVacante, setEditingVacante] = useState<Vacante | null>(null)
  const [formData, setFormData] = useState({
    titulo: '',
    descripcion: '',
    ubicacion: '',
    salarioMin: '',
    salarioMax: '',
    estatus: 'BORRADOR' as EstatusVacante,
    prioridad: 'MEDIA' as PrioridadVacante,
  })

  const openCreateDialog = () => {
    setEditingVacante(null)
    setFormData({
      titulo: '',
      descripcion: '',
      ubicacion: '',
      salarioMin: '',
      salarioMax: '',
      estatus: 'BORRADOR',
      prioridad: 'MEDIA',
    })
    setIsDialogOpen(true)
  }

  const openEditDialog = (vacante: Vacante) => {
    setEditingVacante(vacante)
    setFormData({
      titulo: vacante.titulo,
      descripcion: vacante.descripcion || '',
      ubicacion: vacante.ubicacion || '',
      salarioMin: vacante.salarioMin?.toString() || '',
      salarioMax: vacante.salarioMax?.toString() || '',
      estatus: vacante.estatus,
      prioridad: vacante.prioridad,
    })
    setIsDialogOpen(true)
  }

  const handleSubmit = () => {
    const data: Partial<Vacante> = {
      titulo: formData.titulo,
      descripcion: formData.descripcion || null,
      ubicacion: formData.ubicacion || null,
      salarioMin: formData.salarioMin ? parseFloat(formData.salarioMin) : null,
      salarioMax: formData.salarioMax ? parseFloat(formData.salarioMax) : null,
      estatus: formData.estatus,
      prioridad: formData.prioridad,
    }

    if (editingVacante) {
      onUpdate(editingVacante.id, data)
    } else {
      onCreate(data)
    }

    setIsDialogOpen(false)
  }

  const canCreate = userRole === 'ADMIN' || userRole === 'GERENTE'
  const canEdit = userRole === 'ADMIN' || userRole === 'GERENTE'
  const canDelete = userRole === 'ADMIN'

  return (
    <>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <Briefcase className="h-6 w-6 text-primary" />
            Vacantes
          </h2>
          {canCreate && (
            <Button onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Nueva Vacante
            </Button>
          )}
        </div>

        {/* Grid de vacantes */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {vacantes.map((vacante) => {
            const estatusConfig = ESTATUS_CONFIG[vacante.estatus]
            const prioridadConfig = PRIORIDAD_CONFIG[vacante.prioridad]
            const EstatusIcon = estatusConfig.icon

            return (
              <Card
                key={vacante.id}
                className="card-hover cursor-pointer"
                onClick={() => onSelect(vacante.id)}
              >
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="text-lg line-clamp-1">{vacante.titulo}</CardTitle>
                      <div className="flex items-center gap-2">
                        <Badge className={prioridadConfig.color}>
                          {prioridadConfig.label}
                        </Badge>
                        <Badge className={estatusConfig.color}>
                          {EstatusIcon && <EstatusIcon className="h-3 w-3 mr-1" />}
                          {estatusConfig.label}
                        </Badge>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()}>
                        <DropdownMenuItem onClick={() => onSelect(vacante.id)}>
                          <Eye className="mr-2 h-4 w-4" />
                          Ver detalle
                        </DropdownMenuItem>
                        {canEdit && (
                          <DropdownMenuItem onClick={() => openEditDialog(vacante)}>
                            <Edit2 className="mr-2 h-4 w-4" />
                            Editar
                          </DropdownMenuItem>
                        )}
                        {vacante.estatus === 'PUBLICADA' && canEdit && (
                          <DropdownMenuItem onClick={() => onUpdate(vacante.id, { estatus: 'PAUSADA' })}>
                            <Pause className="mr-2 h-4 w-4" />
                            Pausar
                          </DropdownMenuItem>
                        )}
                        {vacante.estatus === 'PAUSADA' && canEdit && (
                          <DropdownMenuItem onClick={() => onUpdate(vacante.id, { estatus: 'PUBLICADA' })}>
                            <Play className="mr-2 h-4 w-4" />
                            Reactivar
                          </DropdownMenuItem>
                        )}
                        {canDelete && (
                          <>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              onClick={() => onDelete(vacante.id)}
                              className="text-destructive"
                            >
                              <Trash2 className="mr-2 h-4 w-4" />
                              Eliminar
                            </DropdownMenuItem>
                          </>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {vacante.descripcion && (
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {vacante.descripcion}
                    </p>
                  )}

                  <div className="flex flex-wrap gap-3 text-sm text-muted-foreground">
                    {vacante.ubicacion && (
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        <span>{vacante.ubicacion}</span>
                      </div>
                    )}

                    {vacante.salarioMin && vacante.salarioMax && (
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4" />
                        <span>
                          ${vacante.salarioMin.toLocaleString()} - ${vacante.salarioMax.toLocaleString()}
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="flex items-center gap-1 text-sm">
                      <Users className="h-4 w-4 text-primary" />
                      <span>{vacante.candidatosCount || 0} candidatos</span>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(vacante.createdAt), 'dd MMM yyyy', { locale: es })}
                    </span>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {vacantes.length === 0 && (
          <Card className="py-12">
            <CardContent className="text-center">
              <Briefcase className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No hay vacantes</h3>
              <p className="text-muted-foreground mb-4">
                Comienza creando tu primera vacante
              </p>
              {canCreate && (
                <Button onClick={openCreateDialog}>
                  <Plus className="h-4 w-4 mr-2" />
                  Crear Vacante
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Dialog de creación/edición */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>
              {editingVacante ? 'Editar Vacante' : 'Nueva Vacante'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="titulo">Título *</Label>
              <Input
                id="titulo"
                value={formData.titulo}
                onChange={(e) => setFormData({ ...formData, titulo: e.target.value })}
                placeholder="Ej: Senior Full Stack Developer"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="descripcion">Descripción</Label>
              <Textarea
                id="descripcion"
                value={formData.descripcion}
                onChange={(e) => setFormData({ ...formData, descripcion: e.target.value })}
                placeholder="Descripción del puesto..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="ubicacion">Ubicación</Label>
                <Input
                  id="ubicacion"
                  value={formData.ubicacion}
                  onChange={(e) => setFormData({ ...formData, ubicacion: e.target.value })}
                  placeholder="Ciudad de México"
                />
              </div>

              <div className="space-y-2">
                <Label>Estatus</Label>
                <Select
                  value={formData.estatus}
                  onValueChange={(v) => setFormData({ ...formData, estatus: v as EstatusVacante })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BORRADOR">Borrador</SelectItem>
                    <SelectItem value="PUBLICADA">Publicada</SelectItem>
                    <SelectItem value="PAUSADA">Pausada</SelectItem>
                    <SelectItem value="CERRADA">Cerrada</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="salarioMin">Salario Mínimo</Label>
                <Input
                  id="salarioMin"
                  type="number"
                  value={formData.salarioMin}
                  onChange={(e) => setFormData({ ...formData, salarioMin: e.target.value })}
                  placeholder="35000"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="salarioMax">Salario Máximo</Label>
                <Input
                  id="salarioMax"
                  type="number"
                  value={formData.salarioMax}
                  onChange={(e) => setFormData({ ...formData, salarioMax: e.target.value })}
                  placeholder="55000"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Prioridad</Label>
              <Select
                value={formData.prioridad}
                onValueChange={(v) => setFormData({ ...formData, prioridad: v as PrioridadVacante })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="BAJA">Baja</SelectItem>
                  <SelectItem value="MEDIA">Media</SelectItem>
                  <SelectItem value="ALTA">Alta</SelectItem>
                  <SelectItem value="URGENTE">Urgente</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancelar
            </Button>
            <Button onClick={handleSubmit} disabled={!formData.titulo}>
              {editingVacante ? 'Guardar Cambios' : 'Crear Vacante'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
