'use client'

import { useState, useMemo } from 'react'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Checkbox } from '@/components/ui/checkbox'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Search,
  MoreHorizontal,
  ArrowUpDown,
  Users,
  ChevronLeft,
  ChevronRight,
  Trash2,
  FileText,
  ArrowRight,
} from 'lucide-react'
import { format } from 'date-fns'
import { es } from 'date-fns/locale'

// Types
type EstatusCandidato = 'REGISTRADO' | 'EN_PROCESO' | 'ENTREVISTA' | 'CONTRATADO' | 'RECHAZADO'
type FuenteCandidato = 'LINKEDIN' | 'OCC' | 'COMPUTRABAJA' | 'REFERIDO' | 'AGENCIA' | 'FERIA_EMPLEO' | 'UNIVERSIDAD' | 'RED_SOCIAL' | 'OTRO'

interface Candidato {
  id: string
  nombre: string
  apellido: string
  email: string
  telefono?: string | null
  fuente: FuenteCandidato
  estatus: EstatusCandidato
  notas?: string | null
  createdAt: string
  vacante?: { id: string; titulo: string } | null
  reclutador?: { id: string; name: string | null } | null
  documentos?: { id: string; nombre: string; tipo: string; url: string; createdAt: string }[]
}

interface CandidatesTableProps {
  candidatos: Candidato[]
  onSelectCandidato: (id: string) => void
  onStatusChange: (id: string, estatus: EstatusCandidato) => void
  onBulkAction: (ids: string[], action: string, data?: any) => void
  onDelete: (id: string) => void
}

// Estatus badge colors
const ESTATUS_COLORS: Record<EstatusCandidato, string> = {
  REGISTRADO: 'bg-slate-500/20 text-slate-400 border-slate-500/30',
  EN_PROCESO: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
  ENTREVISTA: 'bg-teal-500/20 text-teal-400 border-teal-500/30',
  CONTRATADO: 'bg-green-500/20 text-green-400 border-green-500/30',
  RECHAZADO: 'bg-red-500/20 text-red-400 border-red-500/30',
}

const ESTATUS_LABELS: Record<EstatusCandidato, string> = {
  REGISTRADO: 'Registrado',
  EN_PROCESO: 'En Proceso',
  ENTREVISTA: 'Entrevista',
  CONTRATADO: 'Contratado',
  RECHAZADO: 'Rechazado',
}

const FUENTE_LABELS: Record<FuenteCandidato, string> = {
  LINKEDIN: 'LinkedIn',
  OCC: 'OCC',
  COMPUTRABAJA: 'Computrabajo',
  REFERIDO: 'Referido',
  AGENCIA: 'Agencia',
  FERIA_EMPLEO: 'Feria de Empleo',
  UNIVERSIDAD: 'Universidad',
  RED_SOCIAL: 'Red Social',
  OTRO: 'Otro',
}

export function CandidatesTable({
  candidatos,
  onSelectCandidato,
  onStatusChange,
  onBulkAction,
  onDelete,
}: CandidatesTableProps) {
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [search, setSearch] = useState('')
  const [filtroEstatus, setFiltroEstatus] = useState<string>('all')
  const [sortBy, setSortBy] = useState<string>('createdAt')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc')
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(15)

  // Filtrar y ordenar
  const candidatosFiltrados = useMemo(() => {
    let filtered = [...candidatos]

    // Búsqueda
    if (search) {
      const searchLower = search.toLowerCase()
      filtered = filtered.filter(
        (c) =>
          c.nombre.toLowerCase().includes(searchLower) ||
          c.apellido.toLowerCase().includes(searchLower) ||
          c.email.toLowerCase().includes(searchLower)
      )
    }

    // Filtro estatus
    if (filtroEstatus !== 'all') {
      filtered = filtered.filter((c) => c.estatus === filtroEstatus)
    }

    // Ordenamiento
    filtered.sort((a, b) => {
      let aVal: any = a[sortBy as keyof Candidato]
      let bVal: any = b[sortBy as keyof Candidato]

      if (sortBy === 'nombre') {
        aVal = `${a.nombre} ${a.apellido}`
        bVal = `${b.nombre} ${b.apellido}`
      }

      if (aVal === null || aVal === undefined) return 1
      if (bVal === null || bVal === undefined) return -1

      const comparison = aVal < bVal ? -1 : aVal > bVal ? 1 : 0
      return sortOrder === 'asc' ? comparison : -comparison
    })

    return filtered
  }, [candidatos, search, filtroEstatus, sortBy, sortOrder])

  // Paginación
  const totalPages = Math.ceil(candidatosFiltrados.length / pageSize)
  const paginatedCandidatos = candidatosFiltrados.slice(
    (page - 1) * pageSize,
    page * pageSize
  )

  // Selección
  const allSelected = paginatedCandidatos.length > 0 && paginatedCandidatos.every((c) => selectedIds.has(c.id))
  const someSelected = paginatedCandidatos.some((c) => selectedIds.has(c.id))

  const toggleSelectAll = () => {
    if (allSelected) {
      setSelectedIds(new Set())
    } else {
      setSelectedIds(new Set(paginatedCandidatos.map((c) => c.id)))
    }
  }

  const toggleSelect = (id: string) => {
    const newSelected = new Set(selectedIds)
    if (newSelected.has(id)) {
      newSelected.delete(id)
    } else {
      newSelected.add(id)
    }
    setSelectedIds(newSelected)
  }

  const handleBulkAction = (action: string, data?: any) => {
    if (selectedIds.size > 0) {
      onBulkAction(Array.from(selectedIds), action, data)
      setSelectedIds(new Set())
    }
  }

  const toggleSort = (column: string) => {
    if (sortBy === column) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      setSortBy(column)
      setSortOrder('desc')
    }
  }

  return (
    <Card>
      <CardHeader className="pb-4">
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Candidatos
            <Badge variant="secondary" className="ml-2">
              {candidatosFiltrados.length}
            </Badge>
          </CardTitle>

          <div className="flex flex-wrap gap-2 items-center">
            {/* Búsqueda */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setPage(1)
                }}
                className="pl-9 w-48"
              />
            </div>

            {/* Filtro estatus */}
            <Select
              value={filtroEstatus}
              onValueChange={(v) => {
                setFiltroEstatus(v)
                setPage(1)
              }}
            >
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Estatus" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                {Object.entries(ESTATUS_LABELS).map(([key, label]) => (
                  <SelectItem key={key} value={key}>
                    {label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Acciones masivas */}
            {selectedIds.size > 0 && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    {selectedIds.size} seleccionados
                    <MoreHorizontal className="ml-2 h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => handleBulkAction('cambiar_estatus', 'EN_PROCESO')}>
                    <ArrowRight className="mr-2 h-4 w-4" />
                    Mover a En Proceso
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleBulkAction('cambiar_estatus', 'ENTREVISTA')}>
                    <ArrowRight className="mr-2 h-4 w-4" />
                    Mover a Entrevista
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    onClick={() => handleBulkAction('eliminar')}
                    className="text-destructive"
                  >
                    <Trash2 className="mr-2 h-4 w-4" />
                    Eliminar ({selectedIds.size})
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12">
                  <Checkbox
                    checked={allSelected}
                    onCheckedChange={toggleSelectAll}
                    aria-label="Seleccionar todos"
                  />
                </TableHead>
                <TableHead>
                  <Button variant="ghost" size="sm" onClick={() => toggleSort('nombre')}>
                    Nombre
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead>Email</TableHead>
                <TableHead>
                  <Button variant="ghost" size="sm" onClick={() => toggleSort('estatus')}>
                    Estatus
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead>Vacante</TableHead>
                <TableHead>Fuente</TableHead>
                <TableHead>
                  <Button variant="ghost" size="sm" onClick={() => toggleSort('createdAt')}>
                    Fecha
                    <ArrowUpDown className="ml-2 h-4 w-4" />
                  </Button>
                </TableHead>
                <TableHead className="w-12"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {paginatedCandidatos.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                    No se encontraron candidatos
                  </TableCell>
                </TableRow>
              ) : (
                paginatedCandidatos.map((candidato) => (
                  <TableRow
                    key={candidato.id}
                    className="cursor-pointer"
                    onClick={() => onSelectCandidato(candidato.id)}
                  >
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <Checkbox
                        checked={selectedIds.has(candidato.id)}
                        onCheckedChange={() => toggleSelect(candidato.id)}
                        aria-label={`Seleccionar ${candidato.nombre}`}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-8 w-8">
                          <AvatarFallback className="bg-primary/20 text-primary text-xs">
                            {candidato.nombre[0]}
                            {candidato.apellido[0]}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">
                            {candidato.nombre} {candidato.apellido}
                          </p>
                          {candidato.telefono && (
                            <p className="text-xs text-muted-foreground">{candidato.telefono}</p>
                          )}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{candidato.email}</TableCell>
                    <TableCell>
                      <Badge
                        variant="outline"
                        className={ESTATUS_COLORS[candidato.estatus]}
                      >
                        {ESTATUS_LABELS[candidato.estatus]}
                      </Badge>
                    </TableCell>
                    <TableCell className="max-w-32 truncate">
                      {candidato.vacante?.titulo || '-'}
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary">{FUENTE_LABELS[candidato.fuente]}</Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {format(new Date(candidato.createdAt), 'dd MMM yyyy', { locale: es })}
                    </TableCell>
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => onSelectCandidato(candidato.id)}>
                            <FileText className="mr-2 h-4 w-4" />
                            Ver detalle
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem
                            onClick={() => onDelete(candidato.id)}
                            className="text-destructive"
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Eliminar
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        {/* Paginación */}
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Filas por página:</span>
            <Select
              value={String(pageSize)}
              onValueChange={(v) => {
                setPageSize(Number(v))
                setPage(1)
              }}
            >
              <SelectTrigger className="w-16">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15</SelectItem>
                <SelectItem value="30">30</SelectItem>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              Página {page} de {totalPages || 1}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setPage(Math.max(1, page - 1))}
              disabled={page === 1}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setPage(Math.min(totalPages, page + 1))}
              disabled={page >= totalPages}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
