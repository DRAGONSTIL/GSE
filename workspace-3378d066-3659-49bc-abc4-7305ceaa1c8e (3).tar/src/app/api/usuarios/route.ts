// ATLAS GSE - API de Usuarios

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { UserCreateSchema, UserUpdateSchema } from '@/lib/validations'

// GET - Listar usuarios
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const empresaId = searchParams.get('empresaId')
    const equipoId = searchParams.get('equipoId')

    let where: any = {}

    if (session.user.rol === 'ADMIN') {
      if (empresaId) where.empresaId = empresaId
      if (equipoId) where.equipoId = equipoId
    } else if (session.user.rol === 'GERENTE') {
      where.empresaId = session.user.empresaId
      if (equipoId) where.equipoId = equipoId
    } else {
      // Reclutador solo ve su equipo
      where.equipoId = session.user.equipoId
    }

    const usuarios = await db.user.findMany({
      where,
      select: {
        id: true,
        email: true,
        name: true,
        imagen: true,
        rol: true,
        activo: true,
        empresaId: true,
        equipoId: true,
        createdAt: true,
        empresa: { select: { id: true, nombre: true } },
        equipo: { select: { id: true, nombre: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ usuarios })
  } catch (error) {
    console.error('Error obteniendo usuarios:', error)
    return NextResponse.json(
      { error: 'Error al obtener usuarios', details: String(error) },
      { status: 500 }
    )
  }
}

// POST - Crear usuario (usado después de aceptar invitación)
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Solo ADMIN y GERENTE pueden crear usuarios directamente
    if (session.user.rol === 'RECLUTADOR') {
      return NextResponse.json({ error: 'No tienes permiso para crear usuarios' }, { status: 403 })
    }

    const body = await request.json()
    const data = UserCreateSchema.parse(body)

    // Verificar que no existe el email
    const existingUser = await db.user.findUnique({
      where: { email: data.email },
    })

    if (existingUser) {
      return NextResponse.json({ error: 'Ya existe un usuario con ese email' }, { status: 400 })
    }

    // Si es GERENTE, usar su empresa
    if (session.user.rol === 'GERENTE' && session.user.empresaId) {
      data.empresaId = session.user.empresaId
    }

    const usuario = await db.user.create({
      data,
      select: {
        id: true,
        email: true,
        name: true,
        rol: true,
        empresa: { select: { id: true, nombre: true } },
        equipo: { select: { id: true, nombre: true } },
      },
    })

    return NextResponse.json(usuario, { status: 201 })
  } catch (error) {
    console.error('Error creando usuario:', error)
    return NextResponse.json(
      { error: 'Error al crear usuario', details: String(error) },
      { status: 500 }
    )
  }
}

// PUT - Actualizar usuario
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('id')

    if (!userId) {
      return NextResponse.json({ error: 'ID de usuario requerido' }, { status: 400 })
    }

    // Buscar usuario a editar
    const usuarioAEditar = await db.user.findUnique({
      where: { id: userId },
    })

    if (!usuarioAEditar) {
      return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 })
    }

    // Verificar permisos
    if (session.user.rol === 'RECLUTADOR') {
      // Reclutador solo puede editarse a sí mismo
      if (userId !== session.user.id) {
        return NextResponse.json({ error: 'No tienes permiso para editar este usuario' }, { status: 403 })
      }
    } else if (session.user.rol === 'GERENTE') {
      // Gerente solo puede editar usuarios de su empresa
      if (usuarioAEditar.empresaId !== session.user.empresaId) {
        return NextResponse.json({ error: 'No tienes permiso para editar este usuario' }, { status: 403 })
      }
      // Gerente no puede cambiar el rol a ADMIN
    }

    const body = await request.json()
    const data = UserUpdateSchema.parse(body)

    // Si se está asignando un equipo, obtener la empresa del equipo
    if (data.equipoId) {
      const equipo = await db.equipo.findUnique({
        where: { id: data.equipoId },
      })
      if (equipo) {
        data.empresaId = equipo.empresaId ?? undefined
      }
    }

    // ADMIN no puede ser degradado por otros usuarios
    if (session.user.rol !== 'ADMIN' && usuarioAEditar.rol === 'ADMIN' && data.rol && data.rol !== 'ADMIN') {
      return NextResponse.json({ error: 'No puedes cambiar el rol de un administrador' }, { status: 403 })
    }

    // Gerente no puede crear ADMINs
    if (session.user.rol === 'GERENTE' && data.rol === 'ADMIN') {
      return NextResponse.json({ error: 'No tienes permiso para asignar el rol de administrador' }, { status: 403 })
    }

    const usuario = await db.user.update({
      where: { id: userId },
      data,
      select: {
        id: true,
        email: true,
        name: true,
        rol: true,
        activo: true,
        empresa: { select: { id: true, nombre: true } },
        equipo: { select: { id: true, nombre: true } },
      },
    })

    // Crear actividad
    await db.actividad.create({
      data: {
        tipo: 'NOTA_AGREGADA',
        descripcion: `Usuario actualizado: ${usuario.name || usuario.email}`,
        entidad: 'usuario',
        entidadId: userId,
        usuarioId: session.user.id,
      },
    })

    return NextResponse.json(usuario)
  } catch (error) {
    console.error('Error actualizando usuario:', error)
    return NextResponse.json(
      { error: 'Error al actualizar usuario', details: String(error) },
      { status: 500 }
    )
  }
}
