// ATLAS GSE - API de Actividades

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// GET - Listar actividades
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const limit = parseInt(searchParams.get('limit') || '50')
    const candidatoId = searchParams.get('candidatoId')
    const tipo = searchParams.get('tipo')

    const where: any = {}

    // Filtrar por acceso
    if (session.user.rol === 'RECLUTADOR') {
      where.OR = [
        { usuarioId: session.user.id },
        { candidato: { reclutadorId: session.user.id } },
      ]
    } else if (session.user.rol === 'GERENTE') {
      const usuarios = await db.user.findMany({
        where: { empresaId: session.user.empresaId },
        select: { id: true },
      })
      where.OR = [
        { usuarioId: { in: usuarios.map(u => u.id) } },
        { candidato: { equipo: { empresaId: session.user.empresaId } } },
      ]
    }

    if (candidatoId) where.candidatoId = candidatoId
    if (tipo) where.tipo = tipo

    const actividades = await db.actividad.findMany({
      where,
      include: {
        usuario: { select: { id: true, name: true, email: true } },
        candidato: { select: { id: true, nombre: true, apellido: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
    })

    return NextResponse.json({ actividades })
  } catch (error) {
    console.error('Error obteniendo actividades:', error)
    return NextResponse.json(
      { error: 'Error al obtener actividades' },
      { status: 500 }
    )
  }
}
