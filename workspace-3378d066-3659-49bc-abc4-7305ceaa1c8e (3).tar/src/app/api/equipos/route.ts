// ATLAS GSE - API de Equipos

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { EquipoCreateSchema, EquipoUpdateSchema } from '@/lib/validations'
import { checkRateLimit, getRateLimitIdentifier } from '@/lib/rate-limit'

// GET - Listar equipos
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const empresaId = searchParams.get('empresaId')

    let where: any = {}

    if (session.user.rol === 'ADMIN') {
      if (empresaId) where.empresaId = empresaId
    } else {
      where.empresaId = session.user.empresaId
    }

    const equipos = await db.equipo.findMany({
      where,
      include: {
        empresa: { select: { id: true, nombre: true } },
        _count: { select: { usuarios: true, candidatos: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    // Transformar para incluir conteos
    const equiposConConteo = equipos.map((e) => ({
      ...e,
      usuariosCount: e._count.usuarios,
      candidatosCount: e._count.candidatos,
      _count: undefined,
    }))

    return NextResponse.json({ equipos: equiposConConteo })
  } catch (error) {
    console.error('Error obteniendo equipos:', error)
    return NextResponse.json(
      { error: 'Error al obtener equipos', details: String(error) },
      { status: 500 }
    )
  }
}

// POST - Crear equipo
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Solo ADMIN y GERENTE pueden crear equipos
    if (session.user.rol === 'RECLUTADOR') {
      return NextResponse.json({ error: 'No tienes permiso para crear equipos' }, { status: 403 })
    }

    // Rate limiting
    const rateLimitResult = checkRateLimit(
      getRateLimitIdentifier(request, session.user.id),
      'create'
    )
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: rateLimitResult.error },
        { status: 429, headers: rateLimitResult.headers }
      )
    }

    const body = await request.json()
    const data = EquipoCreateSchema.parse(body)

    // Si es GERENTE, usar su empresa
    if (session.user.rol === 'GERENTE') {
      data.empresaId = session.user.empresaId!
    }

    const equipo = await db.equipo.create({
      data,
      include: {
        empresa: { select: { id: true, nombre: true } },
      },
    })

    return NextResponse.json(equipo, { status: 201 })
  } catch (error) {
    console.error('Error creando equipo:', error)
    return NextResponse.json(
      { error: 'Error al crear equipo', details: String(error) },
      { status: 500 }
    )
  }
}

// PUT - Actualizar equipo
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Solo ADMIN y GERENTE pueden actualizar equipos
    if (session.user.rol === 'RECLUTADOR') {
      return NextResponse.json({ error: 'No tienes permiso para actualizar equipos' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'ID de equipo requerido' }, { status: 400 })
    }

    const body = await request.json()
    const data = EquipoUpdateSchema.parse(body)

    // Verificar que el equipo existe
    const equipo = await db.equipo.findUnique({
      where: { id },
      include: { empresa: true },
    })

    if (!equipo) {
      return NextResponse.json({ error: 'Equipo no encontrado' }, { status: 404 })
    }

    // Si es GERENTE, verificar que el equipo pertenece a su empresa
    if (session.user.rol === 'GERENTE' && equipo.empresaId !== session.user.empresaId) {
      return NextResponse.json({ error: 'No tienes permiso para editar este equipo' }, { status: 403 })
    }

    const updatedEquipo = await db.equipo.update({
      where: { id },
      data,
      include: {
        empresa: { select: { id: true, nombre: true } },
      },
    })

    return NextResponse.json(updatedEquipo)
  } catch (error) {
    console.error('Error actualizando equipo:', error)
    return NextResponse.json(
      { error: 'Error al actualizar equipo', details: String(error) },
      { status: 500 }
    )
  }
}

// DELETE - Eliminar equipo
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Solo ADMIN puede eliminar equipos
    if (session.user.rol !== 'ADMIN') {
      return NextResponse.json({ error: 'No tienes permiso para eliminar equipos' }, { status: 403 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'ID de equipo requerido' }, { status: 400 })
    }

    await db.equipo.delete({
      where: { id },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error eliminando equipo:', error)
    return NextResponse.json(
      { error: 'Error al eliminar equipo', details: String(error) },
      { status: 500 }
    )
  }
}
