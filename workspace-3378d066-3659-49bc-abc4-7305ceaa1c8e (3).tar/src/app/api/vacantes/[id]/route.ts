// ATLAS GSE - API de Vacante por ID

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { VacanteUpdateSchema } from '@/lib/validations'

// GET - Obtener vacante por ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { id } = await params

    const vacante = await db.vacante.findUnique({
      where: { id },
      include: {
        empresa: { select: { id: true, nombre: true } },
        reclutador: { select: { id: true, name: true, email: true } },
        candidatos: {
          select: {
            id: true,
            nombre: true,
            apellido: true,
            email: true,
            estatus: true,
          },
          take: 10,
          orderBy: { createdAt: 'desc' },
        },
        _count: { select: { candidatos: true } },
      },
    })

    if (!vacante) {
      return NextResponse.json({ error: 'Vacante no encontrada' }, { status: 404 })
    }

    // Verificar permisos
    if (session.user.rol !== 'ADMIN') {
      if (vacante.empresaId !== session.user.empresaId) {
        return NextResponse.json({ error: 'No tienes acceso a esta vacante' }, { status: 403 })
      }
    }

    return NextResponse.json({
      ...vacante,
      candidatosCount: vacante._count.candidatos,
      _count: undefined,
    })
  } catch (error) {
    console.error('Error obteniendo vacante:', error)
    return NextResponse.json(
      { error: 'Error al obtener vacante', details: String(error) },
      { status: 500 }
    )
  }
}

// PUT - Actualizar vacante
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Solo GERENTE y ADMIN pueden editar vacantes
    if (session.user.rol === 'RECLUTADOR') {
      return NextResponse.json({ error: 'No tienes permiso para editar vacantes' }, { status: 403 })
    }

    const { id } = await params
    const body = await request.json()
    const data = VacanteUpdateSchema.parse(body)

    // Verificar que la vacante existe
    const vacanteExistente = await db.vacante.findUnique({
      where: { id },
    })

    if (!vacanteExistente) {
      return NextResponse.json({ error: 'Vacante no encontrada' }, { status: 404 })
    }

    // Verificar permisos
    if (session.user.rol === 'GERENTE' && vacanteExistente.empresaId !== session.user.empresaId) {
      return NextResponse.json({ error: 'No tienes permiso para editar esta vacante' }, { status: 403 })
    }

    // Actualizar vacante
    const vacante = await db.vacante.update({
      where: { id },
      data,
      include: {
        empresa: { select: { id: true, nombre: true } },
        reclutador: { select: { id: true, name: true } },
      },
    })

    return NextResponse.json(vacante)
  } catch (error) {
    console.error('Error actualizando vacante:', error)
    return NextResponse.json(
      { error: 'Error al actualizar vacante', details: String(error) },
      { status: 500 }
    )
  }
}

// DELETE - Eliminar vacante
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Solo ADMIN puede eliminar vacantes
    if (session.user.rol !== 'ADMIN') {
      return NextResponse.json({ error: 'Solo los administradores pueden eliminar vacantes' }, { status: 403 })
    }

    const { id } = await params

    // Verificar que la vacante existe
    const vacante = await db.vacante.findUnique({
      where: { id },
    })

    if (!vacante) {
      return NextResponse.json({ error: 'Vacante no encontrada' }, { status: 404 })
    }

    // Desasociar candidatos (vacanteId a null)
    await db.candidato.updateMany({
      where: { vacanteId: id },
      data: { vacanteId: null },
    })

    // Eliminar vacante
    await db.vacante.delete({
      where: { id },
    })

    return NextResponse.json({ message: 'Vacante eliminada correctamente' })
  } catch (error) {
    console.error('Error eliminando vacante:', error)
    return NextResponse.json(
      { error: 'Error al eliminar vacante', details: String(error) },
      { status: 500 }
    )
  }
}
