// ATLAS GSE - API de Vacantes

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { VacanteCreateSchema, VacanteFilterSchema } from '@/lib/validations'
import { checkRateLimit, getRateLimitIdentifier } from '@/lib/rate-limit'

// GET - Listar vacantes
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const filters = VacanteFilterSchema.parse({
      estatus: searchParams.get('estatus') || undefined,
      empresaId: searchParams.get('empresaId') || undefined,
      reclutadorId: searchParams.get('reclutadorId') || undefined,
      page: searchParams.get('page') || 1,
      limit: searchParams.get('limit') || 50,
    })

    const skip = (filters.page - 1) * filters.limit

    // Construir filtros
    const where: any = {}

    // Filtrar por empresa según el rol
    if (session.user.rol === 'ADMIN') {
      // Admin ve todas
      if (filters.empresaId) where.empresaId = filters.empresaId
    } else {
      where.empresaId = session.user.empresaId
    }

    if (filters.estatus) where.estatus = filters.estatus
    if (filters.reclutadorId) where.reclutadorId = filters.reclutadorId

    // Obtener vacantes con conteo de candidatos
    const [vacantes, total] = await Promise.all([
      db.vacante.findMany({
        where,
        include: {
          empresa: { select: { id: true, nombre: true } },
          reclutador: { select: { id: true, name: true } },
          _count: { select: { candidatos: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: filters.limit,
      }),
      db.vacante.count({ where }),
    ])

    // Transformar para incluir conteo
    const vacantesConConteo = vacantes.map((v) => ({
      ...v,
      candidatosCount: v._count.candidatos,
      _count: undefined,
    }))

    return NextResponse.json({
      vacantes: vacantesConConteo,
      pagination: {
        page: filters.page,
        limit: filters.limit,
        total,
        totalPages: Math.ceil(total / filters.limit),
      },
    })
  } catch (error) {
    console.error('Error obteniendo vacantes:', error)
    return NextResponse.json(
      { error: 'Error al obtener vacantes', details: String(error) },
      { status: 500 }
    )
  }
}

// POST - Crear vacante
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Solo GERENTE y ADMIN pueden crear vacantes
    if (session.user.rol === 'RECLUTADOR') {
      return NextResponse.json({ error: 'No tienes permiso para crear vacantes' }, { status: 403 })
    }

    // Rate limiting
    const rateLimitResult = checkRateLimit(
      getRateLimitIdentifier(request, session.user.id),
      'create'
    )
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: rateLimitResult.error },
        { status: 429, headers: rateLimitResult.headers }
      )
    }

    const body = await request.json()
    const data = VacanteCreateSchema.parse(body)

    // Si es GERENTE, usar su empresa
    if (session.user.rol === 'GERENTE') {
      data.empresaId = session.user.empresaId!
    }

    // Crear vacante
    const vacante = await db.vacante.create({
      data,
      include: {
        empresa: { select: { id: true, nombre: true } },
        reclutador: { select: { id: true, name: true } },
      },
    })

    return NextResponse.json(vacante, { status: 201 })
  } catch (error) {
    console.error('Error creando vacante:', error)
    return NextResponse.json(
      { error: 'Error al crear vacante', details: String(error) },
      { status: 500 }
    )
  }
}
