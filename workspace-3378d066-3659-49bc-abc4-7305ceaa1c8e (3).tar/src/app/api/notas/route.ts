// ATLAS GSE - API de Notas

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { z } from 'zod'

const NotaCreateSchema = z.object({
  titulo: z.string().optional(),
  contenido: z.string().min(1),
  tipo: z.string().optional(),
  entidad: z.string().optional(),
  entidadId: z.string().optional(),
  candidatoId: z.string().optional(),
  vacanteId: z.string().optional(),
})

// GET - Listar notas
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })

    const { searchParams } = new URL(request.url)
    const candidatoId = searchParams.get('candidatoId')
    const entidad = searchParams.get('entidad')
    const entidadId = searchParams.get('entidadId')

    const where: any = { archived: false }
    if (candidatoId) where.candidatoId = candidatoId
    if (entidad && entidadId) {
      where.entidad = entidad
      where.entidadId = entidadId
    }

    const notas = await db.nota.findMany({
      where,
      include: {
        usuario: { select: { id: true, name: true, email: true } },
        candidato: { select: { id: true, nombre: true, apellido: true } },
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    })

    return NextResponse.json({ notas })
  } catch (error) {
    console.error('Error al obtener notas:', error)
    return NextResponse.json({ error: 'Error al obtener notas' }, { status: 500 })
  }
}

// POST - Crear nota
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })

    const body = await request.json()
    const data = NotaCreateSchema.parse(body)

    const nota = await db.nota.create({
      data: {
        ...data,
        usuarioId: session.user.id,
      },
      include: {
        usuario: { select: { id: true, name: true, email: true } },
        candidato: { select: { id: true, nombre: true, apellido: true } },
      },
    })

    // Registrar actividad si hay candidato
    if (data.candidatoId) {
      await db.actividad.create({
        data: {
          tipo: 'NOTA_AGREGADA',
          descripcion: `Nota agregada: ${data.titulo || 'Sin título'}`,
          entidad: 'candidato',
          entidadId: data.candidatoId,
          usuarioId: session.user.id,
          candidatoId: data.candidatoId,
        },
      })
    }

    return NextResponse.json(nota, { status: 201 })
  } catch (error) {
    console.error('Error al crear nota:', error)
    return NextResponse.json({ error: 'Error al crear nota' }, { status: 500 })
  }
}

// PUT - Actualizar nota
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })

    const body = await request.json()
    const { id, ...data } = body

    if (!id) return NextResponse.json({ error: 'ID requerido' }, { status: 400 })

    const nota = await db.nota.update({
      where: { id },
      data,
      include: {
        usuario: { select: { id: true, name: true, email: true } },
        candidato: { select: { id: true, nombre: true, apellido: true } },
      },
    })

    return NextResponse.json(nota)
  } catch (error) {
    console.error('Error al actualizar nota:', error)
    return NextResponse.json({ error: 'Error al actualizar nota' }, { status: 500 })
  }
}

// DELETE - Eliminar nota (archivar)
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) return NextResponse.json({ error: 'ID requerido' }, { status: 400 })

    // Archivar en lugar de eliminar
    await db.nota.update({
      where: { id },
      data: { archived: true },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error al eliminar nota:', error)
    return NextResponse.json({ error: 'Error al eliminar nota' }, { status: 500 })
  }
}
