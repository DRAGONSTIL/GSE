// ATLAS GSE - API de Documentos
// Almacenamiento en Base de Datos para persistencia en la nube

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { checkRateLimit, getRateLimitIdentifier } from '@/lib/rate-limit'

// Tipos de archivos permitidos
const ALLOWED_TYPES: Record<string, string[]> = {
  'application/pdf': ['.pdf'],
  'application/msword': ['.doc'],
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'],
  'image/jpeg': ['.jpg', '.jpeg'],
  'image/png': ['.png'],
  'image/gif': ['.gif'],
  'image/webp': ['.webp'],
}

const MAX_FILE_SIZE = 10 * 1024 * 1024 // 10MB

// GET - Listar documentos de un candidato
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const candidatoId = searchParams.get('candidatoId')

    if (!candidatoId) {
      return NextResponse.json({ error: 'candidatoId requerido' }, { status: 400 })
    }

    // Verificar acceso al candidato
    const candidato = await db.candidato.findUnique({
      where: { id: candidatoId },
    })

    if (!candidato) {
      return NextResponse.json({ error: 'Candidato no encontrado' }, { status: 404 })
    }

    if (session.user.rol === 'RECLUTADOR' && candidato.reclutadorId !== session.user.id) {
      return NextResponse.json({ error: 'No tienes acceso a este candidato' }, { status: 403 })
    }

    const documentos = await db.documento.findMany({
      where: { candidatoId },
      orderBy: { createdAt: 'desc' },
      // No incluir contenido en el listado para reducir tamaño
      select: {
        id: true,
        nombre: true,
        nombreOriginal: true,
        tipo: true,
        url: true,
        tamanho: true,
        mimetype: true,
        candidatoId: true,
        createdAt: true,
      }
    })

    return NextResponse.json({ documentos })
  } catch (error) {
    console.error('Error obteniendo documentos:', error)
    return NextResponse.json(
      { error: 'Error al obtener documentos', details: String(error) },
      { status: 500 }
    )
  }
}

// POST - Subir documento (guardar en BD)
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Rate limiting
    const rateLimitResult = checkRateLimit(
      getRateLimitIdentifier(request, session.user.id),
      'create'
    )
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: rateLimitResult.error },
        { status: 429, headers: rateLimitResult.headers }
      )
    }

    const formData = await request.formData()
    const file = formData.get('file') as File
    const candidatoId = formData.get('candidatoId') as string
    const tipo = (formData.get('tipo') as string) || 'CV'

    if (!file || !candidatoId) {
      return NextResponse.json({ error: 'Archivo y candidatoId son requeridos' }, { status: 400 })
    }

    // Verificar tamaño
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json({ error: 'El archivo excede el tamaño máximo de 10MB' }, { status: 400 })
    }

    // Verificar tipo
    if (!ALLOWED_TYPES[file.type]) {
      return NextResponse.json(
        { error: 'Tipo de archivo no permitido. Permitidos: PDF, Word, Imágenes' },
        { status: 400 }
      )
    }

    // Verificar acceso al candidato
    const candidato = await db.candidato.findUnique({
      where: { id: candidatoId },
    })

    if (!candidato) {
      return NextResponse.json({ error: 'Candidato no encontrado' }, { status: 404 })
    }

    if (session.user.rol === 'RECLUTADOR' && candidato.reclutadorId !== session.user.id) {
      return NextResponse.json({ error: 'No tienes acceso a este candidato' }, { status: 403 })
    }

    // Convertir archivo a base64 para almacenamiento en BD
    const bytes = await file.arrayBuffer()
    const buffer = Buffer.from(bytes)
    const base64 = buffer.toString('base64')
    const contenido = `data:${file.type};base64,${base64}`

    // Generar ID único para el documento
    const timestamp = Date.now()
    const randomStr = Math.random().toString(36).substring(7)
    const documentoId = `${timestamp}-${randomStr}`

    // Crear registro en BD con el contenido
    const documento = await db.documento.create({
      data: {
        nombre: file.name,
        nombreOriginal: file.name,
        tipo: tipo as any,
        url: `/api/documentos/download/${documentoId}`,
        tamanho: file.size,
        mimetype: file.type,
        candidatoId,
        subidoPorId: session.user.id,
        contenido, // Guardar en BD para persistencia
      },
    })

    // Retornar sin el contenido para no sobrecargar la respuesta
    return NextResponse.json({
      id: documento.id,
      nombre: documento.nombre,
      tipo: documento.tipo,
      url: documento.url,
      tamanho: documento.tamanho,
      candidatoId: documento.candidatoId,
      createdAt: documento.createdAt,
    }, { status: 201 })
  } catch (error) {
    console.error('Error subiendo documento:', error)
    return NextResponse.json(
      { error: 'Error al subir documento', details: String(error) },
      { status: 500 }
    )
  }
}

// DELETE - Eliminar documento
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const id = searchParams.get('id')

    if (!id) {
      return NextResponse.json({ error: 'ID requerido' }, { status: 400 })
    }

    const documento = await db.documento.findUnique({
      where: { id },
      include: { candidato: true },
    })

    if (!documento) {
      return NextResponse.json({ error: 'Documento no encontrado' }, { status: 404 })
    }

    // Verificar permisos
    if (session.user.rol === 'RECLUTADOR' && documento.candidato.reclutadorId !== session.user.id) {
      return NextResponse.json({ error: 'No tienes permiso para eliminar este documento' }, { status: 403 })
    }

    // Eliminar registro (el contenido se elimina con cascade)
    await db.documento.delete({
      where: { id },
    })

    return NextResponse.json({ message: 'Documento eliminado correctamente' })
  } catch (error) {
    console.error('Error eliminando documento:', error)
    return NextResponse.json(
      { error: 'Error al eliminar documento', details: String(error) },
      { status: 500 }
    )
  }
}
