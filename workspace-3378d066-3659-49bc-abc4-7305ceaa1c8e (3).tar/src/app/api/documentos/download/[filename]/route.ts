// ATLAS GSE - API de Descarga de Documentos
// Lee documentos desde la BD (persistente en la nube)

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ filename: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { filename } = await params

    // Buscar documento por URL (que contiene el ID generado)
    const documento = await db.documento.findFirst({
      where: {
        url: { contains: filename }
      },
      include: { candidato: true },
    })

    if (!documento) {
      return NextResponse.json({ error: 'Documento no encontrado' }, { status: 404 })
    }

    // Verificar permisos
    if (session.user.rol === 'RECLUTADOR' && documento.candidato.reclutadorId !== session.user.id) {
      return NextResponse.json({ error: 'No tienes acceso a este documento' }, { status: 403 })
    }

    // Si tiene contenido en BD, servir desde ahí
    if (documento.contenido) {
      // Extraer el base64 del data URI
      const matches = documento.contenido.match(/^data:(.+);base64,(.+)$/)
      if (matches) {
        const mimetype = matches[1]
        const base64 = matches[2]
        const buffer = Buffer.from(base64, 'base64')

        return new NextResponse(buffer, {
          headers: {
            'Content-Type': mimetype,
            'Content-Disposition': `inline; filename="${encodeURIComponent(documento.nombre)}"`,
            'Content-Length': buffer.length.toString(),
          },
        })
      }
    }

    return NextResponse.json({ error: 'Contenido no disponible' }, { status: 404 })
  } catch (error) {
    console.error('Error descargando documento:', error)
    return NextResponse.json(
      { error: 'Error al descargar documento' },
      { status: 500 }
    )
  }
}
