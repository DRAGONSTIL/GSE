// ATLAS GSE - API de Envío de Emails

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { EmailSendSchema } from '@/lib/validations'
import { sendEmail } from '@/lib/email'
import { checkRateLimit, getRateLimitIdentifier } from '@/lib/rate-limit'

// POST - Enviar email
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Solo GERENTE y ADMIN pueden enviar emails
    if (session.user.rol === 'RECLUTADOR') {
      return NextResponse.json({ error: 'No tienes permiso para enviar emails' }, { status: 403 })
    }

    // Rate limiting
    const rateLimitResult = checkRateLimit(
      getRateLimitIdentifier(request, session.user.id),
      'create'
    )
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: rateLimitResult.error },
        { status: 429, headers: rateLimitResult.headers }
      )
    }

    const body = await request.json()
    const data = EmailSendSchema.parse(body)

    // Enviar email
    const result = await sendEmail(data)

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || 'Error al enviar email' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      message: 'Email enviado correctamente',
      id: result.id,
    })
  } catch (error) {
    console.error('Error enviando email:', error)
    return NextResponse.json(
      { error: 'Error al enviar email', details: String(error) },
      { status: 500 }
    )
  }
}
