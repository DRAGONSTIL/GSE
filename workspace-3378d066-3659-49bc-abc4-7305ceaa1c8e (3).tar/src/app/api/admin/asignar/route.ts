// ATLAS GSE - API Admin: Asignaciones

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

// POST - Asignar usuario a equipo
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    if (session.user.rol === 'RECLUTADOR') {
      return NextResponse.json({ error: 'No tienes permisos para asignar' }, { status: 403 })
    }

    const body = await request.json()
    const { usuarioId, equipoId, candidatoIds, reclutadorId, vacanteId, action } = body

    // Asignar usuario a equipo
    if (usuarioId && equipoId) {
      // Verificar que el usuario existe
      const usuario = await db.user.findUnique({
        where: { id: usuarioId },
      })

      if (!usuario) {
        return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 })
      }

      // Verificar que el equipo existe
      const equipo = await db.equipo.findUnique({
        where: { id: equipoId },
      })

      if (!equipo) {
        return NextResponse.json({ error: 'Equipo no encontrado' }, { status: 404 })
      }

      // Si es GERENTE, verificar que el equipo pertenece a su empresa
      if (session.user.rol === 'GERENTE' && equipo.empresaId !== session.user.empresaId) {
        return NextResponse.json({ error: 'No tienes permisos para asignar a este equipo' }, { status: 403 })
      }

      // Asignar usuario al equipo
      const updatedUser = await db.user.update({
        where: { id: usuarioId },
        data: { 
          equipoId,
          empresaId: equipo.empresaId, // También asignar la empresa del equipo
        },
        include: {
          equipo: { select: { id: true, nombre: true } },
        },
      })

      // Crear actividad
      await db.actividad.create({
        data: {
          tipo: 'NOTA_AGREGADA',
          descripcion: `Usuario asignado al equipo ${equipo.nombre}`,
          entidad: 'usuario',
          entidadId: usuarioId,
          usuarioId: session.user.id,
        },
      })

      return NextResponse.json({ 
        message: 'Usuario asignado al equipo correctamente',
        usuario: updatedUser,
      })
    }

    // Acciones de candidatos
    if (!candidatoIds || !Array.isArray(candidatoIds) || candidatoIds.length === 0) {
      return NextResponse.json({ error: 'Se requieren IDs de candidatos o datos de usuario' }, { status: 400 })
    }

    let result

    switch (action) {
      case 'asignar_reclutador':
        if (!reclutadorId) {
          return NextResponse.json({ error: 'Se requiere ID del reclutador' }, { status: 400 })
        }
        // Verificar que el reclutador pertenece a la misma empresa
        const reclutador = await db.user.findUnique({
          where: { id: reclutadorId },
        })
        if (!reclutador || reclutador.empresaId !== session.user.empresaId) {
          return NextResponse.json({ error: 'Reclutador no válido' }, { status: 400 })
        }
        result = await db.candidato.updateMany({
          where: { id: { in: candidatoIds } },
          data: { reclutadorId },
        })
        break

      case 'asignar_vacante':
        if (!vacanteId) {
          return NextResponse.json({ error: 'Se requiere ID de la vacante' }, { status: 400 })
        }
        result = await db.candidato.updateMany({
          where: { id: { in: candidatoIds } },
          data: { vacanteId },
        })
        break

      case 'desasignar_reclutador':
        result = await db.candidato.updateMany({
          where: { id: { in: candidatoIds } },
          data: { reclutadorId: null },
        })
        break

      case 'desasignar_vacante':
        result = await db.candidato.updateMany({
          where: { id: { in: candidatoIds } },
          data: { vacanteId: null },
        })
        break

      default:
        return NextResponse.json({ error: 'Acción no válida' }, { status: 400 })
    }

    // Crear actividades
    await Promise.all(
      candidatoIds.map(id =>
        db.actividad.create({
          data: {
            tipo: action.toUpperCase() as any,
            descripcion: `Asignación realizada por ${session.user.name}`,
            candidatoId: id,
            usuarioId: session.user.id,
          },
        })
      )
    )

    return NextResponse.json({ message: 'Asignación realizada', count: result.count })
  } catch (error) {
    console.error('Error en asignación:', error)
    return NextResponse.json(
      { error: 'Error al realizar asignación', details: String(error) },
      { status: 500 }
    )
  }
}

// DELETE - Remover usuario de equipo
export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    if (session.user.rol === 'RECLUTADOR') {
      return NextResponse.json({ error: 'No tienes permisos para remover' }, { status: 403 })
    }

    const body = await request.json()
    const { usuarioId, candidatoIds, action } = body

    // Remover usuario de equipo
    if (usuarioId) {
      const usuario = await db.user.findUnique({
        where: { id: usuarioId },
      })

      if (!usuario) {
        return NextResponse.json({ error: 'Usuario no encontrado' }, { status: 404 })
      }

      // Si es GERENTE, verificar que el usuario pertenece a su empresa
      if (session.user.rol === 'GERENTE' && usuario.empresaId !== session.user.empresaId) {
        return NextResponse.json({ error: 'No tienes permisos para remover este usuario' }, { status: 403 })
      }

      // Remover del equipo
      await db.user.update({
        where: { id: usuarioId },
        data: { equipoId: null },
      })

      // Crear actividad
      await db.actividad.create({
        data: {
          tipo: 'NOTA_AGREGADA',
          descripcion: `Usuario removido del equipo`,
          entidad: 'usuario',
          entidadId: usuarioId,
          usuarioId: session.user.id,
        },
      })

      return NextResponse.json({ message: 'Usuario removido del equipo' })
    }

    // Acciones de candidatos
    if (candidatoIds && Array.isArray(candidatoIds)) {
      let result
      switch (action) {
        case 'desasignar_reclutador':
          result = await db.candidato.updateMany({
            where: { id: { in: candidatoIds } },
            data: { reclutadorId: null },
          })
          break
        case 'desasignar_vacante':
          result = await db.candidato.updateMany({
            where: { id: { in: candidatoIds } },
            data: { vacanteId: null },
          })
          break
        default:
          return NextResponse.json({ error: 'Acción no válida' }, { status: 400 })
      }
      return NextResponse.json({ message: 'Asignación removida', count: result.count })
    }

    return NextResponse.json({ error: 'Se requiere usuarioId o candidatoIds' }, { status: 400 })
  } catch (error) {
    console.error('Error al remover:', error)
    return NextResponse.json(
      { error: 'Error al remover', details: String(error) },
      { status: 500 }
    )
  }
}
