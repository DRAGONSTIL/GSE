// ATLAS GSE - API de Candidato por ID

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { CandidatoUpdateSchema } from '@/lib/validations'

// GET - Obtener candidato por ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { id } = await params

    const candidato = await db.candidato.findUnique({
      where: { id },
      include: {
        vacante: { select: { id: true, titulo: true, estatus: true } },
        reclutador: { select: { id: true, name: true, email: true } },
        equipo: { select: { id: true, nombre: true } },
        documentos: true,
      },
    })

    if (!candidato) {
      return NextResponse.json({ error: 'Candidato no encontrado' }, { status: 404 })
    }

    // Verificar permisos
    if (session.user.rol === 'RECLUTADOR' && candidato.reclutadorId !== session.user.id) {
      return NextResponse.json({ error: 'No tienes acceso a este candidato' }, { status: 403 })
    }

    if (session.user.rol === 'GERENTE') {
      const equipo = await db.equipo.findUnique({
        where: { id: candidato.equipoId },
      })
      if (equipo?.empresaId !== session.user.empresaId) {
        return NextResponse.json({ error: 'No tienes acceso a este candidato' }, { status: 403 })
      }
    }

    return NextResponse.json(candidato)
  } catch (error) {
    console.error('Error obteniendo candidato:', error)
    return NextResponse.json(
      { error: 'Error al obtener candidato', details: String(error) },
      { status: 500 }
    )
  }
}

// PUT - Actualizar candidato
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { id } = await params
    const body = await request.json()
    const data = CandidatoUpdateSchema.parse(body)

    // Verificar que el candidato existe
    const candidatoExistente = await db.candidato.findUnique({
      where: { id },
    })

    if (!candidatoExistente) {
      return NextResponse.json({ error: 'Candidato no encontrado' }, { status: 404 })
    }

    // Verificar permisos
    if (session.user.rol === 'RECLUTADOR' && candidatoExistente.reclutadorId !== session.user.id) {
      return NextResponse.json({ error: 'No tienes permiso para editar este candidato' }, { status: 403 })
    }

    // Actualizar candidato
    const candidato = await db.candidato.update({
      where: { id },
      data,
      include: {
        vacante: { select: { id: true, titulo: true } },
        reclutador: { select: { id: true, name: true } },
        equipo: { select: { id: true, nombre: true } },
      },
    })

    // Registrar actividad si cambió el estatus
    if (data.estatus && data.estatus !== candidatoExistente.estatus) {
      await db.actividad.create({
        data: {
          tipo: 'ACTUALIZAR_ESTATUS',
          descripcion: `Estatus cambiado de ${candidatoExistente.estatus} a ${data.estatus}`,
          entidad: 'candidato',
          entidadId: id,
          usuarioId: session.user.id,
          candidatoId: id,
        },
      })
    }

    return NextResponse.json(candidato)
  } catch (error) {
    console.error('Error actualizando candidato:', error)
    return NextResponse.json(
      { error: 'Error al actualizar candidato', details: String(error) },
      { status: 500 }
    )
  }
}

// DELETE - Eliminar candidato
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { id } = await params

    // Verificar que el candidato existe
    const candidato = await db.candidato.findUnique({
      where: { id },
    })

    if (!candidato) {
      return NextResponse.json({ error: 'Candidato no encontrado' }, { status: 404 })
    }

    // Verificar permisos
    if (session.user.rol === 'RECLUTADOR' && candidato.reclutadorId !== session.user.id) {
      return NextResponse.json({ error: 'No tienes permiso para eliminar este candidato' }, { status: 403 })
    }

    // Eliminar documentos asociados
    await db.documento.deleteMany({
      where: { candidatoId: id },
    })

    // Eliminar candidato
    await db.candidato.delete({
      where: { id },
    })

    return NextResponse.json({ message: 'Candidato eliminado correctamente' })
  } catch (error) {
    console.error('Error eliminando candidato:', error)
    return NextResponse.json(
      { error: 'Error al eliminar candidato', details: String(error) },
      { status: 500 }
    )
  }
}
