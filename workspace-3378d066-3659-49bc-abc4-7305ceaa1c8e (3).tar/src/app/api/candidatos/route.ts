// ATLAS GSE - API de Candidatos

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { CandidatoCreateSchema, CandidatoFilterSchema } from '@/lib/validations'
import { checkRateLimit, getRateLimitIdentifier } from '@/lib/rate-limit'

// GET - Listar candidatos
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    const { searchParams } = new URL(request.url)
    const filters = CandidatoFilterSchema.parse({
      estatus: searchParams.get('estatus') || undefined,
      reclutadorId: searchParams.get('reclutadorId') || undefined,
      vacanteId: searchParams.get('vacanteId') || undefined,
      fuente: searchParams.get('fuente') || undefined,
      search: searchParams.get('search') || undefined,
      page: searchParams.get('page') || 1,
      limit: searchParams.get('limit') || 15,
      sortBy: searchParams.get('sortBy') || 'createdAt',
      sortOrder: searchParams.get('sortOrder') || 'desc',
    })

    const skip = (filters.page - 1) * filters.limit

    // Construir filtros
    const where: any = {}

    // Filtrar por empresa/equipo según el rol
    if (session.user.rol === 'ADMIN') {
      // Admin ve todos
    } else if (session.user.rol === 'GERENTE') {
      where.equipo = { empresaId: session.user.empresaId }
    } else {
      // Reclutador solo ve sus candidatos
      where.reclutadorId = session.user.id
    }

    if (filters.estatus) where.estatus = filters.estatus
    if (filters.reclutadorId) where.reclutadorId = filters.reclutadorId
    if (filters.vacanteId) where.vacanteId = filters.vacanteId
    if (filters.fuente) where.fuente = filters.fuente

    if (filters.search) {
      where.OR = [
        { nombre: { contains: filters.search } },
        { apellido: { contains: filters.search } },
        { email: { contains: filters.search } },
      ]
    }

    // Obtener candidatos
    const [candidatos, total] = await Promise.all([
      db.candidato.findMany({
        where,
        include: {
          vacante: { select: { id: true, titulo: true } },
          reclutador: { select: { id: true, name: true } },
          equipo: { select: { id: true, nombre: true } },
          documentos: { select: { id: true, nombre: true, tipo: true } },
        },
        orderBy: { [filters.sortBy || 'createdAt']: filters.sortOrder },
        skip,
        take: filters.limit,
      }),
      db.candidato.count({ where }),
    ])

    return NextResponse.json({
      candidatos,
      pagination: {
        page: filters.page,
        limit: filters.limit,
        total,
        totalPages: Math.ceil(total / filters.limit),
      },
    })
  } catch (error) {
    console.error('Error obteniendo candidatos:', error)
    return NextResponse.json(
      { error: 'Error al obtener candidatos', details: String(error) },
      { status: 500 }
    )
  }
}

// POST - Crear candidato
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Rate limiting
    const rateLimitResult = checkRateLimit(
      getRateLimitIdentifier(request, session.user.id),
      'create'
    )
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: rateLimitResult.error },
        { status: 429, headers: rateLimitResult.headers }
      )
    }

    const body = await request.json()
    const data = CandidatoCreateSchema.parse(body)

    // Verificar permisos
    if (session.user.rol === 'RECLUTADOR') {
      data.reclutadorId = session.user.id
      data.equipoId = session.user.equipoId!
    }

    // Verificar que el equipo existe
    const equipo = await db.equipo.findUnique({
      where: { id: data.equipoId },
    })

    if (!equipo) {
      return NextResponse.json({ error: 'Equipo no encontrado' }, { status: 404 })
    }

    // Crear candidato
    const candidato = await db.candidato.create({
      data,
      include: {
        vacante: { select: { id: true, titulo: true } },
        reclutador: { select: { id: true, name: true } },
        equipo: { select: { id: true, nombre: true } },
      },
    })

    // Registrar actividad
    await db.actividad.create({
      data: {
        tipo: 'CREAR_CANDIDATO',
        descripcion: `Candidato ${candidato.nombre} ${candidato.apellido} registrado`,
        entidad: 'candidato',
        entidadId: candidato.id,
        usuarioId: session.user.id,
        candidatoId: candidato.id,
      },
    })

    return NextResponse.json(candidato, { status: 201 })
  } catch (error) {
    console.error('Error creando candidato:', error)
    return NextResponse.json(
      { error: 'Error al crear candidato', details: String(error) },
      { status: 500 }
    )
  }
}
