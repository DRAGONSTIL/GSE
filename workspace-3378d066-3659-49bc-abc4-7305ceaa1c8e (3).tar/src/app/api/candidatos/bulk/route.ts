// ATLAS GSE - API de Acciones Masivas de Candidatos

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { CandidatoBulkActionSchema } from '@/lib/validations'
import { checkRateLimit, getRateLimitIdentifier } from '@/lib/rate-limit'

// PUT - Acciones masivas
export async function PUT(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'No autorizado' }, { status: 401 })
    }

    // Rate limiting
    const rateLimitResult = checkRateLimit(
      getRateLimitIdentifier(request, session.user.id),
      'create'
    )
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { error: rateLimitResult.error },
        { status: 429, headers: rateLimitResult.headers }
      )
    }

    const body = await request.json()
    const data = CandidatoBulkActionSchema.parse(body)

    // Verificar que los candidatos existen y permisos
    const candidatos = await db.candidato.findMany({
      where: { id: { in: data.ids } },
    })

    if (candidatos.length !== data.ids.length) {
      return NextResponse.json(
        { error: 'Algunos candidatos no fueron encontrados' },
        { status: 404 }
      )
    }

    // Verificar permisos para cada candidato
    if (session.user.rol === 'RECLUTADOR') {
      const noPermitidos = candidatos.filter((c) => c.reclutadorId !== session.user.id)
      if (noPermitidos.length > 0) {
        return NextResponse.json(
          { error: 'No tienes permiso para algunos de los candidatos seleccionados' },
          { status: 403 }
        )
      }
    }

    let result

    switch (data.action) {
      case 'cambiar_estatus':
        if (!data.estatus) {
          return NextResponse.json(
            { error: 'El estatus es requerido para esta acción' },
            { status: 400 }
          )
        }
        result = await db.candidato.updateMany({
          where: { id: { in: data.ids } },
          data: { estatus: data.estatus },
        })
        break

      case 'agregar_nota':
        if (!data.nota) {
          return NextResponse.json(
            { error: 'La nota es requerida para esta acción' },
            { status: 400 }
          )
        }
        // Agregar nota a cada candidato (append)
        for (const candidato of candidatos) {
          const notasActuales = candidato.notas || ''
          const nuevaNota = notasActuales
            ? `${notasActuales}\n\n---\n${new Date().toLocaleDateString('es-MX')}: ${data.nota}`
            : `${new Date().toLocaleDateString('es-MX')}: ${data.nota}`
          await db.candidato.update({
            where: { id: candidato.id },
            data: { notas: nuevaNota },
          })
        }
        result = { count: candidatos.length }
        break

      case 'eliminar':
        // Eliminar documentos primero
        await db.documento.deleteMany({
          where: { candidatoId: { in: data.ids } },
        })
        result = await db.candidato.deleteMany({
          where: { id: { in: data.ids } },
        })
        break

      default:
        return NextResponse.json({ error: 'Acción no válida' }, { status: 400 })
    }

    return NextResponse.json({
      message: `Acción "${data.action}" completada exitosamente`,
      affected: result.count,
    })
  } catch (error) {
    console.error('Error en acción masiva:', error)
    return NextResponse.json(
      { error: 'Error al procesar acción masiva', details: String(error) },
      { status: 500 }
    )
  }
}
