// ATLAS GSE - API de Entrevistas

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { z } from 'zod'

const EntrevistaCreateSchema = z.object({
  candidatoId: z.string().min(1),
  titulo: z.string().optional(),
  tipo: z.string().optional(),
  fecha: z.string().transform(v => new Date(v)),
  duracion: z.number().optional(),
  ubicacion: z.string().optional(),
  enlace: z.string().optional(),
  notas: z.string().optional(),
})

// GET
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })

    const entrevistas = await db.entrevista.findMany({
      include: { candidato: { select: { id: true, nombre: true, apellido: true, email: true } } },
      orderBy: { fecha: 'asc' },
    })
    return NextResponse.json({ entrevistas })
  } catch (error) {
    return NextResponse.json({ error: 'Error al obtener entrevistas' }, { status: 500 })
  }
}

// POST
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'No autorizado' }, { status: 401 })

    const body = await request.json()
    const data = EntrevistaCreateSchema.parse(body)

    const entrevista = await db.entrevista.create({
      data: { ...data, reclutadorId: session.user.id },
      include: { candidato: { select: { id: true, nombre: true, apellido: true, email: true } } },
    })

    await db.actividad.create({
      data: {
        tipo: 'AGENDAR_ENTREVISTA',
        descripcion: `Entrevista agendada`,
        entidad: 'entrevista',
        entidadId: entrevista.id,
        usuarioId: session.user.id,
        candidatoId: data.candidatoId,
      },
    })

    return NextResponse.json(entrevista, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: 'Error al crear entrevista' }, { status: 500 })
  }
}
