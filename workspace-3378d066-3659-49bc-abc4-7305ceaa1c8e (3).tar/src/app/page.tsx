'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession, signIn, signOut } from 'next-auth/react'
import { useTheme } from 'next-themes'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip'
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  FunnelChart,
  Funnel,
  LabelList,
  LineChart,
  Line,
  Legend,
  Area,
  AreaChart,
} from 'recharts'
import { KanbanBoard } from '@/components/atlas/kanban-board'
import { CandidatesTable } from '@/components/atlas/candidates-table'
import { VacantesManager } from '@/components/atlas/vacantes-manager'
import { DocumentosManager } from '@/components/atlas/documentos-manager'
import { NotificationCenter } from '@/components/atlas/notification-center'
import { AdminPanel } from '@/components/atlas/admin-panel'
import { MetasManager } from '@/components/atlas/metas-manager'
import { EntrevistasManager } from '@/components/atlas/entrevistas-manager'
import { NotasTareasManager } from '@/components/atlas/notas-tareas-manager'
import { EmailTemplatesManager } from '@/components/atlas/email-templates-manager'
import { EvaluacionesManager } from '@/components/atlas/evaluaciones-manager'
import { ReportesManager } from '@/components/atlas/reportes-manager'
import { useUIStore } from '@/lib/store'
import { METRICAS_INFO } from '@/lib/validations'
import {
  LogOut,
  Moon,
  Sun,
  Users,
  Briefcase,
  TrendingUp,
  Clock,
  Building2,
  Plus,
  RefreshCw,
  Loader2,
  UserCheck,
  UserX,
  Settings,
  LayoutDashboard,
  Kanban,
  FileText,
  Target,
  Shield,
  ChevronDown,
  Bell,
  Search,
  Filter,
  Download,
  Upload,
  MoreHorizontal,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Info,
  Zap,
  Award,
  BarChart3,
  PieChartIcon,
  ArrowUpRight,
  ArrowDownRight,
  Minus,
  Sparkles,
  Menu,
  X,
  Calendar,
  StickyNote,
  Mail,
  ClipboardList,
  FileBarChart,
} from 'lucide-react'
import { format, subDays, startOfMonth, endOfMonth, differenceInDays } from 'date-fns'
import { es } from 'date-fns/locale'

// Types
type EstatusCandidato = 'REGISTRADO' | 'EN_PROCESO' | 'ENTREVISTA' | 'CONTRATADO' | 'RECHAZADO'
type FuenteCandidato = 'LINKEDIN' | 'OCC' | 'COMPUTRABAJA' | 'REFERIDO' | 'AGENCIA' | 'FERIA_EMPLEO' | 'UNIVERSIDAD' | 'RED_SOCIAL' | 'OTRO'
type EstatusVacante = 'BORRADOR' | 'PUBLICADA' | 'PAUSADA' | 'CERRADA'
type PrioridadVacante = 'BAJA' | 'MEDIA' | 'ALTA' | 'URGENTE'
type TipoDocumento = 'CV' | 'PORTAFOLIO' | 'CERTIFICADO' | 'OTRO'

interface Candidato {
  id: string
  nombre: string
  apellido: string
  email: string
  telefono?: string | null
  fuente: FuenteCandidato
  estatus: EstatusCandidato
  notas?: string | null
  rating?: number | null
  tags?: string | null
  createdAt: string
  vacante?: { id: string; titulo: string } | null
  reclutador?: { id: string; name: string | null } | null
  documentos?: { id: string; nombre: string; tipo: string; url: string; createdAt: string }[]
}

interface Vacante {
  id: string
  titulo: string
  descripcion?: string | null
  ubicacion?: string | null
  salarioMin?: number | null
  salarioMax?: number | null
  estatus: EstatusVacante
  prioridad: PrioridadVacante
  createdAt: string
  candidatosCount?: number
  reclutador?: { id: string; name: string | null } | null
}

// Chart colors
const CHART_COLORS = ['#d4af37', '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899']

export default function ATLASDashboard() {
  const { data: session, status } = useSession()
  const { theme, setTheme } = useTheme()
  const { activeTab, setActiveTab, addNotification } = useUIStore()

  // Data states
  const [candidatos, setCandidatos] = useState<Candidato[]>([])
  const [vacantes, setVacantes] = useState<Vacante[]>([])
  const [loading, setLoading] = useState(true)
  const [sidebarOpen, setSidebarOpen] = useState(false)

  // Modal states
  const [selectedCandidato, setSelectedCandidato] = useState<Candidato | null>(null)
  const [selectedVacante, setSelectedVacante] = useState<Vacante | null>(null)
  const [isCandidatoDialogOpen, setIsCandidatoDialogOpen] = useState(false)
  const [isVacanteDialogOpen, setIsVacanteDialogOpen] = useState(false)
  const [isNewCandidatoDialogOpen, setIsNewCandidatoDialogOpen] = useState(false)
  const [isSyncDialogOpen, setIsSyncDialogOpen] = useState(false)

  // Actividades
  const [candidatoActividades, setCandidatoActividades] = useState<any[]>([])
  const [loadingActividades, setLoadingActividades] = useState(false)
  const [actividadReciente, setActividadReciente] = useState<any[]>([])

  // New candidato form
  const [newCandidatoForm, setNewCandidatoForm] = useState({
    nombre: '',
    apellido: '',
    email: '',
    telefono: '',
    fuente: 'OTRO' as FuenteCandidato,
    vacanteId: '__none__',
    notas: '',
  })

  // Sync form
  const [syncForm, setSyncForm] = useState({
    equipoId: '',
  })

  // Cargar actividades del candidato
  const loadCandidatoActividades = async (candidatoId: string) => {
    setLoadingActividades(true)
    try {
      const res = await fetch(`/api/actividades?candidatoId=${candidatoId}&limit=20`)
      if (res.ok) {
        const data = await res.json()
        setCandidatoActividades(data.actividades || [])
      }
    } catch (error) {
      console.error('Error loading actividades:', error)
    } finally {
      setLoadingActividades(false)
    }
  }

  // Fetch data
  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      const [candidatosRes, vacantesRes, actRes] = await Promise.all([
        fetch('/api/candidatos?limit=100'),
        fetch('/api/vacantes?limit=100'),
        fetch('/api/actividades?limit=10'),
      ])

      if (candidatosRes.ok) {
        const data = await candidatosRes.json()
        setCandidatos(data.candidatos || [])
      }

      if (vacantesRes.ok) {
        const data = await vacantesRes.json()
        setVacantes(data.vacantes || [])
      }

      if (actRes.ok) {
        const actData = await actRes.json()
        setActividadReciente(actData.actividades || [])
      }
    } catch (error) {
      console.error('Error fetching data:', error)
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (session?.user) {
      fetchData()
    }
  }, [session, fetchData])

  // Loading state
  if (status === 'loading') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <div className="relative">
            <div className="w-16 h-16 rounded-full bg-primary/20 animate-pulse" />
            <Building2 className="h-8 w-8 text-primary absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
          </div>
          <p className="text-muted-foreground">Cargando ATLAS GSE...</p>
        </div>
      </div>
    )
  }

  // Not authenticated - Show login
  if (!session) {
    return <LoginPage />
  }

  // Stats calculations
  const stats = {
    total: candidatos.length,
    contratados: candidatos.filter((c) => c.estatus === 'CONTRATADO').length,
    enProceso: candidatos.filter((c) => c.estatus === 'EN_PROCESO' || c.estatus === 'ENTREVISTA').length,
    rechazados: candidatos.filter((c) => c.estatus === 'RECHAZADO').length,
    entrevistas: candidatos.filter((c) => c.estatus === 'ENTREVISTA').length,
  }

  // A) Time to hire - calcular promedio real de días entre createdAt y fechaContratacion
  const candidatosContratados = candidatos.filter((c) => c.estatus === 'CONTRATADO')
  let avgTimeToHire = 0
  if (candidatosContratados.length > 0) {
    // Nota: necesitamos fechaContratacion, pero no está en el tipo actual
    // Por ahora calculamos días en proceso desde createdAt hasta hoy como aproximación
    const diasTotales = candidatosContratados.reduce((acc, c) => {
      return acc + differenceInDays(new Date(), new Date(c.createdAt))
    }, 0)
    avgTimeToHire = Math.round(diasTotales / candidatosContratados.length)
  }

  // B) Trend data - candidatos creados por día en los últimos 7 días
  const hoy = new Date()
  const ultimos7Dias = Array.from({ length: 7 }, (_, i) => {
    const fecha = subDays(hoy, 6 - i)
    return {
      fecha,
      nombre: format(fecha, 'EEE', { locale: es }),
    }
  })
  const trendData = ultimos7Dias.map((dia) => {
    const candidatosDia = candidatos.filter((c) => {
      const fechaCandidato = new Date(c.createdAt)
      return (
        fechaCandidato.getDate() === dia.fecha.getDate() &&
        fechaCandidato.getMonth() === dia.fecha.getMonth() &&
        fechaCandidato.getFullYear() === dia.fecha.getFullYear()
      )
    })
    return {
      name: dia.nombre,
      candidatos: candidatosDia.length,
      contrataciones: candidatosDia.filter((c) => c.estatus === 'CONTRATADO').length,
    }
  })

  // C) Comparación mes actual vs mes anterior
  const mesActualStart = startOfMonth(hoy)
  const mesAnteriorStart = startOfMonth(subDays(mesActualStart, 1))
  const mesAnteriorEnd = endOfMonth(mesAnteriorStart)
  
  const candidatosMesActual = candidatos.filter((c) => new Date(c.createdAt) >= mesActualStart).length
  const candidatosMesAnterior = candidatos.filter((c) => {
    const fecha = new Date(c.createdAt)
    return fecha >= mesAnteriorStart && fecha <= mesAnteriorEnd
  }).length
  
  let porcentajeCambio: number | null = null
  if (candidatosMesAnterior > 0) {
    porcentajeCambio = ((candidatosMesActual - candidatosMesAnterior) / candidatosMesAnterior) * 100
  }

  // E) Calidad promedio - calcular de ratings reales
  const candidatosConRating = candidatos.filter((c) => c.rating !== null && c.rating !== undefined)
  let calidadPromedio = 'N/A'
  if (candidatosConRating.length > 0) {
    const promedio = candidatosConRating.reduce((acc, c) => acc + (c.rating || 0), 0) / candidatosConRating.length
    calidadPromedio = `${promedio.toFixed(1)}/5`
  }

  // F) Tasa de Conversión (era Tasa de Retención)
  const tasaConversion = stats.total > 0 ? ((stats.contratados / stats.total) * 100).toFixed(1) : '0'

  // Chart data - Embudo
  const embudoData = [
    { name: 'Registrados', value: candidatos.filter((c) => c.estatus === 'REGISTRADO').length, fill: CHART_COLORS[0] },
    { name: 'En Proceso', value: candidatos.filter((c) => c.estatus === 'EN_PROCESO').length, fill: CHART_COLORS[1] },
    { name: 'Entrevista', value: candidatos.filter((c) => c.estatus === 'ENTREVISTA').length, fill: CHART_COLORS[2] },
    { name: 'Contratados', value: candidatos.filter((c) => c.estatus === 'CONTRATADO').length, fill: CHART_COLORS[3] },
    { name: 'Rechazados', value: candidatos.filter((c) => c.estatus === 'RECHAZADO').length, fill: CHART_COLORS[4] },
  ].filter((d) => d.value > 0)

  // Chart data - Por fuente
  const fuenteData = Object.entries(
    candidatos.reduce((acc, c) => {
      acc[c.fuente] = (acc[c.fuente] || 0) + 1
      return acc
    }, {} as Record<string, number>)
  ).map(([name, value], i) => ({ name, value, fill: CHART_COLORS[i % CHART_COLORS.length] }))

  // Chart data - Por vacante
  const vacanteData = vacantes
    .filter((v) => v.candidatosCount && v.candidatosCount > 0)
    .slice(0, 5)
    .map((v, i) => ({
      name: v.titulo.length > 20 ? v.titulo.slice(0, 20) + '...' : v.titulo,
      value: v.candidatosCount || 0,
      fill: CHART_COLORS[i % CHART_COLORS.length],
    }))

  // Handlers
  const handleStatusChange = async (id: string, estatus: EstatusCandidato) => {
    try {
      const res = await fetch(`/api/candidatos/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ estatus }),
      })

      if (res.ok) {
        setCandidatos((prev) =>
          prev.map((c) => (c.id === id ? { ...c, estatus } : c))
        )
        addNotification({
          type: 'success',
          title: 'Estatus actualizado',
          message: 'El estatus del candidato fue actualizado correctamente',
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error',
        message: 'No se pudo actualizar el estatus',
      })
    }
  }

  const handleBulkAction = async (ids: string[], action: string, data?: any) => {
    try {
      const res = await fetch('/api/candidatos/bulk', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ids, action, ...data }),
      })

      if (res.ok) {
        fetchData()
        addNotification({
          type: 'success',
          title: 'Acción completada',
          message: `Se procesaron ${ids.length} candidatos`,
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error',
        message: 'No se pudo completar la acción',
      })
    }
  }

  const handleDeleteCandidato = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar este candidato?')) return

    try {
      const res = await fetch(`/api/candidatos/${id}`, { method: 'DELETE' })

      if (res.ok) {
        setCandidatos((prev) => prev.filter((c) => c.id !== id))
        setIsCandidatoDialogOpen(false)
        addNotification({
          type: 'success',
          title: 'Candidato eliminado',
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error al eliminar',
      })
    }
  }

  const handleCreateVacante = async (data: Partial<Vacante>) => {
    try {
      const res = await fetch('/api/vacantes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })

      if (res.ok) {
        const newVacante = await res.json()
        setVacantes((prev) => [...prev, newVacante])
        addNotification({
          type: 'success',
          title: 'Vacante creada',
          message: `Se creó la vacante "${data.titulo}"`,
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error al crear vacante',
      })
    }
  }

  const handleUpdateVacante = async (id: string, data: Partial<Vacante>) => {
    try {
      const res = await fetch(`/api/vacantes/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      })

      if (res.ok) {
        const updated = await res.json()
        setVacantes((prev) => prev.map((v) => (v.id === id ? { ...v, ...updated } : v)))
        addNotification({
          type: 'success',
          title: 'Vacante actualizada',
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error al actualizar vacante',
      })
    }
  }

  const handleDeleteVacante = async (id: string) => {
    if (!confirm('¿Estás seguro de eliminar esta vacante?')) return

    try {
      const res = await fetch(`/api/vacantes/${id}`, { method: 'DELETE' })

      if (res.ok) {
        setVacantes((prev) => prev.filter((v) => v.id !== id))
        setIsVacanteDialogOpen(false)
        addNotification({
          type: 'success',
          title: 'Vacante eliminada',
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error al eliminar vacante',
      })
    }
  }

  const handleCreateCandidato = async () => {
    try {
      const equipoId = session?.user?.equipoId
      if (!equipoId) {
        addNotification({
          type: 'error',
          title: 'Error',
          message: 'No tienes un equipo asignado. Contacta al administrador.',
        })
        return
      }

      // Preparar datos - no enviar __none__ como vacanteId
      const candidatoData = {
        nombre: newCandidatoForm.nombre,
        apellido: newCandidatoForm.apellido,
        email: newCandidatoForm.email,
        telefono: newCandidatoForm.telefono || undefined,
        fuente: newCandidatoForm.fuente,
        vacanteId: newCandidatoForm.vacanteId === '__none__' ? undefined : newCandidatoForm.vacanteId,
        notas: newCandidatoForm.notas || undefined,
        equipoId,
      }

      const res = await fetch('/api/candidatos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(candidatoData),
      })

      const data = await res.json()

      if (res.ok) {
        setCandidatos((prev) => [...prev, data])
        setIsNewCandidatoDialogOpen(false)
        setNewCandidatoForm({
          nombre: '',
          apellido: '',
          email: '',
          telefono: '',
          fuente: 'OTRO',
          vacanteId: '__none__',
          notas: '',
        })
        addNotification({
          type: 'success',
          title: 'Candidato creado',
          message: `Se registró a ${newCandidatoForm.nombre} ${newCandidatoForm.apellido}`,
        })
      } else {
        addNotification({
          type: 'error',
          title: 'Error al crear candidato',
          message: data.error || 'Error desconocido',
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error al crear candidato',
        message: 'Ocurrió un error inesperado',
      })
    }
  }

  const handleUploadDocument = async (file: File, tipo: TipoDocumento) => {
    if (!selectedCandidato) return

    const formData = new FormData()
    formData.append('file', file)
    formData.append('candidatoId', selectedCandidato.id)
    formData.append('tipo', tipo)

    try {
      const res = await fetch('/api/documentos', {
        method: 'POST',
        body: formData,
      })

      if (res.ok) {
        const newDoc = await res.json()
        setSelectedCandidato((prev) =>
          prev ? { ...prev, documentos: [...(prev.documentos || []), newDoc] } : prev
        )
        addNotification({
          type: 'success',
          title: 'Documento subido',
          message: file.name,
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error al subir documento',
      })
    }
  }

  const handleDeleteDocument = async (id: string) => {
    try {
      const res = await fetch(`/api/documentos?id=${id}`, { method: 'DELETE' })

      if (res.ok) {
        setSelectedCandidato((prev) =>
          prev
            ? { ...prev, documentos: prev.documentos?.filter((d) => d.id !== id) }
            : prev
        )
        addNotification({
          type: 'success',
          title: 'Documento eliminado',
        })
      }
    } catch (error) {
      addNotification({
        type: 'error',
        title: 'Error al eliminar documento',
      })
    }
  }

  const handleSync = async () => {
    if (!syncForm.equipoId) {
      addNotification({ type: 'error', title: 'Selecciona un equipo' })
      return
    }

    try {
      const res = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ equipoId: syncForm.equipoId }),
      })

      if (res.ok) {
        const result = await res.json()
        addNotification({
          type: 'success',
          title: 'Sincronización completada',
          message: `${result.resultados?.total || 0} registros procesados`,
        })
        setIsSyncDialogOpen(false)
        fetchData()
      } else {
        const error = await res.json()
        addNotification({ type: 'error', title: error.error || 'Error en sincronización' })
      }
    } catch (error) {
      addNotification({ type: 'error', title: 'Error en sincronización' })
    }
  }

  return (
    <TooltipProvider>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b bg-card/80 backdrop-blur-md sticky top-0 z-50">
          <div className="container mx-auto px-4 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="icon"
                  className="lg:hidden"
                  onClick={() => setSidebarOpen(!sidebarOpen)}
                >
                  <Menu className="h-5 w-5" />
                </Button>

                <div className="flex items-center gap-3">
                  <div className="relative">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-amber-600 flex items-center justify-center shadow-lg shadow-primary/20">
                      <Building2 className="h-5 w-5 text-white" />
                    </div>
                    <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-card" />
                  </div>
                  <div>
                    <h1 className="text-xl font-bold tracking-tight">ATLAS GSE</h1>
                    <p className="text-xs text-muted-foreground hidden sm:block">Sistema de Reclutamiento</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {/* Quick Search */}
                <div className="hidden md:flex relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Buscar..."
                    className="pl-9 w-48 lg:w-64 bg-muted/50"
                  />
                </div>

                <NotificationCenter />

                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
                    >
                      {theme === 'dark' ? (
                        <Sun className="h-5 w-5" />
                      ) : (
                        <Moon className="h-5 w-5" />
                      )}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>Cambiar tema</TooltipContent>
                </Tooltip>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="gap-2 px-2">
                      <Avatar className="h-8 w-8">
                        <AvatarFallback className="bg-primary/20 text-primary text-sm">
                          {session.user?.name?.[0] || session.user?.email?.[0]?.toUpperCase() || 'U'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="hidden sm:block text-left">
                        <p className="text-sm font-medium">{session.user?.name || 'Usuario'}</p>
                        <Badge variant="outline" className="text-xs py-0">
                          {session.user?.rol}
                        </Badge>
                      </div>
                      <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="p-2">
                      <p className="text-sm font-medium">{session.user?.name}</p>
                      <p className="text-xs text-muted-foreground">{session.user?.email}</p>
                    </div>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => setActiveTab('admin')}>
                      <Settings className="mr-2 h-4 w-4" />
                      Configuración
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => signOut()} className="text-destructive">
                      <LogOut className="mr-2 h-4 w-4" />
                      Cerrar Sesión
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          </div>
        </header>

        {/* Main content */}
        <main className="container mx-auto px-4 py-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="mb-6 flex-wrap h-auto gap-1">
              <TabsTrigger value="dashboard" className="gap-2">
                <LayoutDashboard className="h-4 w-4" />
                <span className="hidden sm:inline">Dashboard</span>
              </TabsTrigger>
              <TabsTrigger value="pipeline" className="gap-2">
                <Kanban className="h-4 w-4" />
                <span className="hidden sm:inline">Pipeline</span>
              </TabsTrigger>
              <TabsTrigger value="vacantes" className="gap-2">
                <Briefcase className="h-4 w-4" />
                <span className="hidden sm:inline">Vacantes</span>
              </TabsTrigger>
              <TabsTrigger value="directorio" className="gap-2">
                <Users className="h-4 w-4" />
                <span className="hidden sm:inline">Directorio</span>
              </TabsTrigger>
              <TabsTrigger value="entrevistas" className="gap-2">
                <Calendar className="h-4 w-4" />
                <span className="hidden sm:inline">Entrevistas</span>
              </TabsTrigger>
              <TabsTrigger value="notas" className="gap-2">
                <StickyNote className="h-4 w-4" />
                <span className="hidden sm:inline">Notas</span>
              </TabsTrigger>
              <TabsTrigger value="emails" className="gap-2">
                <Mail className="h-4 w-4" />
                <span className="hidden sm:inline">Emails</span>
              </TabsTrigger>
              <TabsTrigger value="evaluaciones" className="gap-2">
                <ClipboardList className="h-4 w-4" />
                <span className="hidden sm:inline">Evaluaciones</span>
              </TabsTrigger>
              <TabsTrigger value="reportes" className="gap-2">
                <FileBarChart className="h-4 w-4" />
                <span className="hidden sm:inline">Reportes</span>
              </TabsTrigger>
              <TabsTrigger value="metas" className="gap-2">
                <Target className="h-4 w-4" />
                <span className="hidden sm:inline">Metas</span>
              </TabsTrigger>
              {(session.user?.rol === 'ADMIN' || session.user?.rol === 'GERENTE') && (
                <TabsTrigger value="admin" className="gap-2">
                  <Shield className="h-4 w-4" />
                  <span className="hidden sm:inline">Admin</span>
                </TabsTrigger>
              )}
            </TabsList>

            {/* Dashboard Tab */}
            <TabsContent value="dashboard" className="space-y-6 animate-fade-in">
              {/* KPI Cards */}
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                <Card className="relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Total Candidatos
                    </CardTitle>
                    <div className="p-2 rounded-lg bg-primary/10">
                      <Users className="h-5 w-5 text-primary" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{stats.total}</p>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground mt-1">
                      {porcentajeCambio !== null ? (
                        <>
                          {porcentajeCambio >= 0 ? (
                            <ArrowUpRight className="h-3 w-3 text-green-500" />
                          ) : (
                            <ArrowDownRight className="h-3 w-3 text-red-500" />
                          )}
                          <span className={porcentajeCambio >= 0 ? 'text-green-500' : 'text-red-500'}>
                            {porcentajeCambio >= 0 ? '+' : ''}{porcentajeCambio.toFixed(0)}%
                          </span>
                          <span>vs mes anterior</span>
                        </>
                      ) : (
                        <span className="text-muted-foreground">Sin datos previos</span>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card className="relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Contrataciones
                    </CardTitle>
                    <div className="p-2 rounded-lg bg-green-500/10">
                      <UserCheck className="h-5 w-5 text-green-500" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-green-500">{stats.contratados}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {stats.total > 0 ? ((stats.contratados / stats.total) * 100).toFixed(1) : 0}% tasa de conversión
                    </p>
                  </CardContent>
                </Card>

                <Card className="relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      En Proceso
                    </CardTitle>
                    <div className="p-2 rounded-lg bg-amber-500/10">
                      <Clock className="h-5 w-5 text-amber-500" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold text-amber-500">{stats.enProceso}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {stats.entrevistas} en entrevista
                    </p>
                  </CardContent>
                </Card>

                <Card className="relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                  <CardHeader className="flex flex-row items-center justify-between pb-2">
                    <CardTitle className="text-sm font-medium text-muted-foreground">
                      Vacantes Activas
                    </CardTitle>
                    <div className="p-2 rounded-lg bg-blue-500/10">
                      <Briefcase className="h-5 w-5 text-blue-500" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">
                      {vacantes.filter((v) => v.estatus === 'PUBLICADA').length}
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      de {vacantes.length} totales
                    </p>
                  </CardContent>
                </Card>
              </div>

              {/* Secondary KPIs */}
              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg bg-violet-500/10">
                        <Zap className="h-6 w-6 text-violet-500" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Time to Hire</p>
                        <p className="text-2xl font-bold">{avgTimeToHire} días</p>
                        <p className="text-xs text-muted-foreground">
                          {avgTimeToHire > 0 ? 'Promedio de contratación' : 'Sin datos suficientes'}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg bg-cyan-500/10">
                        <Award className="h-6 w-6 text-cyan-500" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Calidad Promedio</p>
                        <p className="text-2xl font-bold">{calidadPromedio}</p>
                        <p className="text-xs text-muted-foreground">Rating de candidatos</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 rounded-lg bg-pink-500/10">
                        <TrendingUp className="h-6 w-6 text-pink-500" />
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Tasa de Conversión</p>
                        <p className="text-2xl font-bold">{tasaConversion}%</p>
                        <p className="text-xs text-muted-foreground">Contratados / Total</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Charts Row 1 */}
              <div className="grid gap-6 lg:grid-cols-2">
                {/* Embudo */}
                <Card className="col-span-1">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <BarChart3 className="h-5 w-5" />
                          Embudo de Reclutamiento
                        </CardTitle>
                        <CardDescription>Distribución por etapa del proceso</CardDescription>
                      </div>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Exportar
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    {embudoData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={280}>
                        <FunnelChart>
                          <RechartsTooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--card))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '8px',
                            }}
                          />
                          <Funnel
                            dataKey="value"
                            data={embudoData}
                            isAnimationActive
                          >
                            <LabelList
                              position="right"
                              fill="hsl(var(--foreground))"
                              stroke="none"
                              dataKey="name"
                            />
                          </Funnel>
                        </FunnelChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="h-64 flex items-center justify-center text-muted-foreground">
                        No hay datos para mostrar
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Por Fuente */}
                <Card className="col-span-1">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <PieChartIcon className="h-5 w-5" />
                      Fuentes de Candidatos
                    </CardTitle>
                    <CardDescription>Origen de los candidatos</CardDescription>
                  </CardHeader>
                  <CardContent>
                    {fuenteData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={280}>
                        <PieChart>
                          <Pie
                            data={fuenteData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            outerRadius={90}
                            label={({ name, percent }) =>
                              `${name} (${(percent * 100).toFixed(0)}%)`
                            }
                            labelLine={false}
                          >
                            {fuenteData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                          </Pie>
                          <RechartsTooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--card))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '8px',
                            }}
                          />
                          <Legend />
                        </PieChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="h-64 flex items-center justify-center text-muted-foreground">
                        No hay datos para mostrar
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Charts Row 2 */}
              <div className="grid gap-6 lg:grid-cols-2">
                {/* Top Vacantes */}
                <Card>
                  <CardHeader>
                    <CardTitle>Top Vacantes por Candidatos</CardTitle>
                  </CardHeader>
                  <CardContent>
                    {vacanteData.length > 0 ? (
                      <ResponsiveContainer width="100%" height={200}>
                        <BarChart data={vacanteData} layout="vertical">
                          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                          <XAxis type="number" stroke="hsl(var(--muted-foreground))" />
                          <YAxis
                            type="category"
                            dataKey="name"
                            stroke="hsl(var(--muted-foreground))"
                            width={150}
                          />
                          <RechartsTooltip
                            contentStyle={{
                              backgroundColor: 'hsl(var(--card))',
                              border: '1px solid hsl(var(--border))',
                              borderRadius: '8px',
                            }}
                          />
                          <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                            {vacanteData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.fill} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    ) : (
                      <div className="h-48 flex items-center justify-center text-muted-foreground">
                        No hay vacantes con candidatos
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Trend */}
                <Card>
                  <CardHeader>
                    <CardTitle>Tendencia Semanal</CardTitle>
                    <CardDescription>Candidatos y contrataciones por día</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ResponsiveContainer width="100%" height={200}>
                      <AreaChart data={trendData}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                        <XAxis dataKey="name" stroke="hsl(var(--muted-foreground))" />
                        <YAxis stroke="hsl(var(--muted-foreground))" />
                        <RechartsTooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                          }}
                        />
                        <Area
                          type="monotone"
                          dataKey="candidatos"
                          stackId="1"
                          stroke={CHART_COLORS[0]}
                          fill={CHART_COLORS[0]}
                          fillOpacity={0.3}
                        />
                        <Area
                          type="monotone"
                          dataKey="contrataciones"
                          stackId="2"
                          stroke={CHART_COLORS[3]}
                          fill={CHART_COLORS[3]}
                          fillOpacity={0.5}
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </CardContent>
                </Card>
              </div>

              {/* Actividad Reciente */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">
                    Actividad Reciente
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {actividadReciente.length === 0 ? (
                    <p className="text-sm text-muted-foreground">
                      No hay actividad reciente
                    </p>
                  ) : (
                    <div className="space-y-3">
                      {actividadReciente.map((act) => (
                        <div key={act.id} className="flex gap-3 items-start">
                          <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm truncate">{act.descripcion}</p>
                            <p className="text-xs text-muted-foreground">
                              {act.usuario?.name || 'Sistema'} · {' '}
                              {format(new Date(act.createdAt), 'dd/MM/yyyy HH:mm', { locale: es })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Pipeline Tab */}
            <TabsContent value="pipeline" className="animate-fade-in">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-bold">Pipeline de Candidatos</h2>
                  <p className="text-muted-foreground">Arrastra las tarjetas para cambiar el estatus</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setIsSyncDialogOpen(true)}>
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Sincronizar
                  </Button>
                  <Button onClick={() => setIsNewCandidatoDialogOpen(true)}>
                    <Plus className="h-4 w-4 mr-2" />
                    Nuevo Candidato
                  </Button>
                </div>
              </div>
              <KanbanBoard
                candidatos={candidatos}
                onStatusChange={handleStatusChange}
                onSelectCandidato={(id) => {
                  const c = candidatos.find((c) => c.id === id)
                  if (c) {
                    setSelectedCandidato(c)
                    setIsCandidatoDialogOpen(true)
                    loadCandidatoActividades(id)
                  }
                }}
              />
            </TabsContent>

            {/* Vacantes Tab */}
            <TabsContent value="vacantes" className="animate-fade-in">
              <VacantesManager
                vacantes={vacantes}
                onCreate={handleCreateVacante}
                onUpdate={handleUpdateVacante}
                onDelete={handleDeleteVacante}
                onSelect={(id) => {
                  const v = vacantes.find((v) => v.id === id)
                  if (v) {
                    setSelectedVacante(v)
                    setIsVacanteDialogOpen(true)
                  }
                }}
                userRole={session.user?.rol || 'RECLUTADOR'}
              />
            </TabsContent>

            {/* Directorio Tab */}
            <TabsContent value="directorio" className="animate-fade-in">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-2xl font-bold">Directorio de Candidatos</h2>
                  <p className="text-muted-foreground">Gestiona y busca candidatos</p>
                </div>
                <Button onClick={() => setIsNewCandidatoDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Nuevo Candidato
                </Button>
              </div>
              <CandidatesTable
                candidatos={candidatos}
                onSelectCandidato={(id) => {
                  const c = candidatos.find((c) => c.id === id)
                  if (c) {
                    setSelectedCandidato(c)
                    setIsCandidatoDialogOpen(true)
                    loadCandidatoActividades(id)
                  }
                }}
                onStatusChange={handleStatusChange}
                onBulkAction={handleBulkAction}
                onDelete={handleDeleteCandidato}
              />
            </TabsContent>

            {/* Entrevistas Tab */}
            <TabsContent value="entrevistas" className="animate-fade-in">
              <EntrevistasManager addNotification={addNotification} />
            </TabsContent>

            {/* Notas y Tareas Tab */}
            <TabsContent value="notas" className="animate-fade-in">
              <NotasTareasManager userId={session.user?.id || ''} addNotification={addNotification} />
            </TabsContent>

            {/* Email Templates Tab */}
            <TabsContent value="emails" className="animate-fade-in">
              <EmailTemplatesManager addNotification={addNotification} />
            </TabsContent>

            {/* Evaluaciones Tab */}
            <TabsContent value="evaluaciones" className="animate-fade-in">
              <EvaluacionesManager 
                candidatos={candidatos.map(c => ({ id: c.id, nombre: c.nombre, apellido: c.apellido, email: c.email }))} 
                addNotification={addNotification} 
              />
            </TabsContent>

            {/* Reportes Tab */}
            <TabsContent value="reportes" className="animate-fade-in">
              <ReportesManager
                candidatos={candidatos}
                vacantes={vacantes}
                addNotification={addNotification}
              />
            </TabsContent>

            {/* Metas Tab */}
            <TabsContent value="metas" className="animate-fade-in">
              <MetasManager
                empresaId={session.user?.empresaId || null}
                userRole={session.user?.rol || 'RECLUTADOR'}
                userId={session.user?.id || ''}
                addNotification={addNotification}
              />
            </TabsContent>

            {/* Admin Tab */}
            <TabsContent value="admin" className="animate-fade-in">
              <AdminPanel
                userRole={session.user?.rol || 'RECLUTADOR'}
                empresaId={session.user?.empresaId || null}
                onRefresh={fetchData}
                addNotification={addNotification}
              />
            </TabsContent>
          </Tabs>
        </main>

        {/* Candidato Detail Dialog */}
        <Dialog open={isCandidatoDialogOpen} onOpenChange={setIsCandidatoDialogOpen}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="flex items-center gap-3">
                <Avatar>
                  <AvatarFallback>
                    {selectedCandidato?.nombre[0]}{selectedCandidato?.apellido[0]}
                  </AvatarFallback>
                </Avatar>
                {selectedCandidato?.nombre} {selectedCandidato?.apellido}
              </DialogTitle>
            </DialogHeader>

            {selectedCandidato && (
              <div className="space-y-6">
                {/* Info Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Email</Label>
                    <p className="font-medium">{selectedCandidato.email}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Teléfono</Label>
                    <p className="font-medium">{selectedCandidato.telefono || 'No registrado'}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Fuente</Label>
                    <p className="font-medium">{selectedCandidato.fuente}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Estatus</Label>
                    <div>
                      <Badge>{selectedCandidato.estatus}</Badge>
                    </div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Vacante</Label>
                    <p className="font-medium">{selectedCandidato.vacante?.titulo || 'Sin asignar'}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Reclutador</Label>
                    <p className="font-medium">{selectedCandidato.reclutador?.name || 'Sin asignar'}</p>
                  </div>
                  {selectedCandidato.rating && (
                    <div className="col-span-2">
                      <Label className="text-muted-foreground">Rating</Label>
                      <div className="flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <span key={star} className={star <= selectedCandidato.rating! ? 'text-amber-500' : 'text-muted'}>
                            ★
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Tags */}
                {selectedCandidato.tags && (
                  <div>
                    <Label className="text-muted-foreground">Etiquetas</Label>
                    <div className="flex flex-wrap gap-2 mt-1">
                      {selectedCandidato.tags.split(',').map((tag, i) => (
                        <Badge key={i} variant="secondary">{tag.trim()}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Notas */}
                {selectedCandidato.notas && (
                  <div>
                    <Label className="text-muted-foreground">Notas</Label>
                    <p className="text-sm mt-1 p-3 bg-muted rounded-lg">
                      {selectedCandidato.notas}
                    </p>
                  </div>
                )}

                {/* Documentos */}
                <DocumentosManager
                  documentos={selectedCandidato.documentos || []}
                  candidatoId={selectedCandidato.id}
                  onUpload={handleUploadDocument}
                  onDelete={handleDeleteDocument}
                />

                {/* Historial de Actividad */}
                <div>
                  <Label className="text-muted-foreground font-semibold">
                    Historial de Actividad
                  </Label>
                  {loadingActividades ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground mt-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Cargando historial...
                    </div>
                  ) : candidatoActividades.length === 0 ? (
                    <p className="text-sm text-muted-foreground mt-2">
                      Sin actividad registrada
                    </p>
                  ) : (
                    <div className="space-y-2 mt-2 max-h-48 overflow-y-auto">
                      {candidatoActividades.map((act) => (
                        <div key={act.id} className="flex gap-3 text-sm p-2 rounded-lg bg-muted/50">
                          <div className="flex-1">
                            <p className="font-medium">{act.descripcion}</p>
                            <p className="text-xs text-muted-foreground">
                              {act.usuario?.name || 'Sistema'} · {' '}
                              {format(new Date(act.createdAt), 'dd/MM/yyyy HH:mm', { locale: es })}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Acciones */}
                <div className="flex gap-2 pt-4 border-t">
                  <Select
                    onValueChange={(v) =>
                      handleStatusChange(selectedCandidato.id, v as EstatusCandidato)
                    }
                  >
                    <SelectTrigger className="w-44">
                      <SelectValue placeholder="Cambiar estatus" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="REGISTRADO">Registrado</SelectItem>
                      <SelectItem value="EN_PROCESO">En Proceso</SelectItem>
                      <SelectItem value="ENTREVISTA">Entrevista</SelectItem>
                      <SelectItem value="CONTRATADO">Contratado</SelectItem>
                      <SelectItem value="RECHAZADO">Rechazado</SelectItem>
                    </SelectContent>
                  </Select>

                  <Button
                    variant="destructive"
                    onClick={() => handleDeleteCandidato(selectedCandidato.id)}
                  >
                    <UserX className="h-4 w-4 mr-2" />
                    Eliminar
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* New Candidato Dialog */}
        <Dialog open={isNewCandidatoDialogOpen} onOpenChange={setIsNewCandidatoDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Nuevo Candidato</DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre *</Label>
                  <Input
                    value={newCandidatoForm.nombre}
                    onChange={(e) =>
                      setNewCandidatoForm({ ...newCandidatoForm, nombre: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Apellido *</Label>
                  <Input
                    value={newCandidatoForm.apellido}
                    onChange={(e) =>
                      setNewCandidatoForm({ ...newCandidatoForm, apellido: e.target.value })
                    }
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Email *</Label>
                <Input
                  type="email"
                  value={newCandidatoForm.email}
                  onChange={(e) =>
                    setNewCandidatoForm({ ...newCandidatoForm, email: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>Teléfono</Label>
                <Input
                  value={newCandidatoForm.telefono}
                  onChange={(e) =>
                    setNewCandidatoForm({ ...newCandidatoForm, telefono: e.target.value })
                  }
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Fuente</Label>
                  <Select
                    value={newCandidatoForm.fuente}
                    onValueChange={(v) =>
                      setNewCandidatoForm({ ...newCandidatoForm, fuente: v as FuenteCandidato })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="LINKEDIN">LinkedIn</SelectItem>
                      <SelectItem value="OCC">OCC</SelectItem>
                      <SelectItem value="COMPUTRABAJA">Computrabajo</SelectItem>
                      <SelectItem value="REFERIDO">Referido</SelectItem>
                      <SelectItem value="AGENCIA">Agencia</SelectItem>
                      <SelectItem value="FERIA_EMPLEO">Feria de Empleo</SelectItem>
                      <SelectItem value="UNIVERSIDAD">Universidad</SelectItem>
                      <SelectItem value="RED_SOCIAL">Red Social</SelectItem>
                      <SelectItem value="OTRO">Otro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Vacante</Label>
                  <Select
                    value={newCandidatoForm.vacanteId}
                    onValueChange={(v) =>
                      setNewCandidatoForm({ ...newCandidatoForm, vacanteId: v })
                    }
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Seleccionar..." />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__none__">Sin vacante específica</SelectItem>
                      {vacantes
                        .filter((v) => v.estatus === 'PUBLICADA')
                        .map((v) => (
                          <SelectItem key={v.id} value={v.id}>
                            {v.titulo}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Notas</Label>
                <Textarea
                  value={newCandidatoForm.notas}
                  onChange={(e) =>
                    setNewCandidatoForm({ ...newCandidatoForm, notas: e.target.value })
                  }
                  rows={3}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsNewCandidatoDialogOpen(false)}>
                Cancelar
              </Button>
              <Button
                onClick={handleCreateCandidato}
                disabled={!newCandidatoForm.nombre || !newCandidatoForm.apellido || !newCandidatoForm.email}
              >
                Crear Candidato
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Vacante Detail Dialog */}
        <Dialog open={isVacanteDialogOpen} onOpenChange={setIsVacanteDialogOpen}>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>{selectedVacante?.titulo}</DialogTitle>
            </DialogHeader>

            {selectedVacante && (
              <div className="space-y-4">
                {selectedVacante.descripcion && (
                  <div>
                    <Label className="text-muted-foreground">Descripción</Label>
                    <p className="text-sm mt-1">{selectedVacante.descripcion}</p>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Ubicación</Label>
                    <p>{selectedVacante.ubicacion || 'No especificada'}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Salario</Label>
                    <p>
                      {selectedVacante.salarioMin && selectedVacante.salarioMax
                        ? `$${selectedVacante.salarioMin.toLocaleString()} - $${selectedVacante.salarioMax.toLocaleString()}`
                        : 'No especificado'}
                    </p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Estatus</Label>
                    <Badge>{selectedVacante.estatus}</Badge>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Prioridad</Label>
                    <Badge variant="outline">{selectedVacante.prioridad}</Badge>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <p className="text-sm text-muted-foreground">
                    {selectedVacante.candidatosCount || 0} candidatos registrados
                  </p>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>

        {/* Sync Dialog */}
        <Dialog open={isSyncDialogOpen} onOpenChange={setIsSyncDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Sincronizar con Google Sheets</DialogTitle>
            </DialogHeader>

            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Selecciona el equipo para sincronizar candidatos desde Google Sheets.
              </p>
              <div className="space-y-2">
                <Label>Equipo</Label>
                <Select
                  value={syncForm.equipoId}
                  onValueChange={(v) => setSyncForm({ ...syncForm, equipoId: v })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar equipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {/* Teams would be loaded dynamically */}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsSyncDialogOpen(false)}>
                Cancelar
              </Button>
              <Button onClick={handleSync}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Sincronizar
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </TooltipProvider>
  )
}

// Login Page Component
function LoginPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [selectedRol, setSelectedRol] = useState<string | null>(null)
  const [googleLoading, setGoogleLoading] = useState(false)

  const handleDemoLogin = async (provider: string, rol: string) => {
    setIsLoading(true)
    setSelectedRol(rol)
    try {
      await signIn(provider, { callbackUrl: '/' })
    } catch (error) {
      console.error('Login error:', error)
    } finally {
      setIsLoading(false)
      setSelectedRol(null)
    }
  }

  const handleGoogleLogin = async () => {
    setGoogleLoading(true)
    try {
      await signIn('google', { callbackUrl: '/' })
    } catch (error) {
      console.error('Google login error:', error)
    } finally {
      setGoogleLoading(false)
    }
  }

  // Check if Google OAuth is configured
  const hasGoogleOAuth = !!(process.env.NODE_ENV === 'development' || 
    (typeof window !== 'undefined' && window.location.hostname !== 'localhost'))

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-primary/5 p-4">
      <Card className="w-full max-w-md border-0 shadow-2xl">
        <CardHeader className="text-center pb-2">
          <div className="relative mx-auto mb-6">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-primary via-amber-500 to-amber-600 flex items-center justify-center shadow-lg shadow-primary/30">
              <Building2 className="h-10 w-10 text-white" />
            </div>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-500 rounded-full border-4 border-card" />
          </div>
          <CardTitle className="text-3xl font-bold tracking-tight">ATLAS GSE</CardTitle>
          <CardDescription className="text-base">
            Sistema Profesional de Gestión de Reclutamiento
          </CardDescription>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Google OAuth Button */}
          <Button
            className="w-full h-12 text-base font-medium bg-white text-gray-700 hover:bg-gray-100 border border-gray-300"
            onClick={handleGoogleLogin}
            disabled={googleLoading}
          >
            {googleLoading ? (
              <Loader2 className="h-5 w-5 mr-2 animate-spin" />
            ) : (
              <svg className="h-5 w-5 mr-2" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
            )}
            Continuar con Google
          </Button>

          <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-card px-3 text-muted-foreground">Acceso Demo</span>
            </div>
          </div>

          <div className="space-y-3">
            <Button
              className="w-full h-12 text-base font-medium"
              onClick={() => handleDemoLogin('demo-admin', 'ADMIN')}
              disabled={isLoading}
            >
              {isLoading && selectedRol === 'ADMIN' ? (
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              ) : (
                <Shield className="h-5 w-5 mr-2" />
              )}
              Entrar como Administrador
            </Button>

            <Button
              className="w-full h-12 text-base font-medium"
              variant="outline"
              onClick={() => handleDemoLogin('demo-gerente', 'GERENTE')}
              disabled={isLoading}
            >
              {isLoading && selectedRol === 'GERENTE' ? (
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              ) : (
                <Users className="h-5 w-5 mr-2" />
              )}
              Entrar como Gerente
            </Button>

            <Button
              className="w-full h-12 text-base font-medium"
              variant="outline"
              onClick={() => handleDemoLogin('demo-reclutador', 'RECLUTADOR')}
              disabled={isLoading}
            >
              {isLoading && selectedRol === 'RECLUTADOR' ? (
                <Loader2 className="h-5 w-5 mr-2 animate-spin" />
              ) : (
                <UserCheck className="h-5 w-5 mr-2" />
              )}
              Entrar como Reclutador
            </Button>
          </div>

          <div className="text-center text-xs text-muted-foreground space-y-1 pt-2 border-t">
            <p className="font-medium">ATLAS GSE v1.0</p>
            <p>Sistema de Gestión de Reclutamiento Empresarial</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
