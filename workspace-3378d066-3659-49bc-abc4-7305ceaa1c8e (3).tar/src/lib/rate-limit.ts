// ATLAS GSE - Rate Limiting en Memoria
// Implementación simple para desarrollo y producción ligera

interface RateLimitEntry {
  count: number
  resetTime: number
}

interface RateLimitConfig {
  windowMs: number // Ventana de tiempo en milisegundos
  maxRequests: number // Máximo de requests permitidos
}

// Store en memoria para rate limiting
const rateLimitStore = new Map<string, RateLimitEntry>()

// Configuraciones por defecto para diferentes tipos de endpoints
export const rateLimitConfigs = {
  // Login y autenticación
  auth: {
    windowMs: 60 * 1000, // 1 minuto
    maxRequests: 10, // 10 intentos por minuto
  },
  // Creación de recursos
  create: {
    windowMs: 60 * 1000, // 1 minuto
    maxRequests: 30, // 30 creaciones por minuto
  },
  // APIs generales
  general: {
    windowMs: 60 * 1000, // 1 minuto
    maxRequests: 100, // 100 requests por minuto
  },
  // Sincronización
  sync: {
    windowMs: 5 * 60 * 1000, // 5 minutos
    maxRequests: 5, // 5 sincronizaciones por 5 minutos
  },
}

// Limpiar entradas expiradas periódicamente
function cleanupExpiredEntries() {
  const now = Date.now()
  for (const [key, entry] of rateLimitStore.entries()) {
    if (now > entry.resetTime) {
      rateLimitStore.delete(key)
    }
  }
}

// Ejecutar limpieza cada minuto
if (typeof setInterval !== 'undefined') {
  setInterval(cleanupExpiredEntries, 60 * 1000)
}

// Función principal de rate limiting
export function rateLimit(
  identifier: string,
  config: RateLimitConfig = rateLimitConfigs.general
): { success: boolean; remaining: number; resetTime: number; retryAfter?: number } {
  const now = Date.now()
  const key = identifier

  const entry = rateLimitStore.get(key)

  if (!entry || now > entry.resetTime) {
    // Crear nueva entrada
    const newEntry: RateLimitEntry = {
      count: 1,
      resetTime: now + config.windowMs,
    }
    rateLimitStore.set(key, newEntry)

    return {
      success: true,
      remaining: config.maxRequests - 1,
      resetTime: newEntry.resetTime,
    }
  }

  if (entry.count >= config.maxRequests) {
    // Rate limit excedido
    return {
      success: false,
      remaining: 0,
      resetTime: entry.resetTime,
      retryAfter: Math.ceil((entry.resetTime - now) / 1000),
    }
  }

  // Incrementar contador
  entry.count++
  rateLimitStore.set(key, entry)

  return {
    success: true,
    remaining: config.maxRequests - entry.count,
    resetTime: entry.resetTime,
  }
}

// Middleware helper para APIs
export function checkRateLimit(
  identifier: string,
  type: keyof typeof rateLimitConfigs = 'general'
): { success: boolean; headers: Record<string, string>; error?: string } {
  const config = rateLimitConfigs[type]
  const result = rateLimit(identifier, config)

  const headers: Record<string, string> = {
    'X-RateLimit-Limit': String(config.maxRequests),
    'X-RateLimit-Remaining': String(result.remaining),
    'X-RateLimit-Reset': String(Math.ceil(result.resetTime / 1000)),
  }

  if (!result.success) {
    headers['Retry-After'] = String(result.retryAfter || 60)
    return {
      success: false,
      headers,
      error: `Demasiadas solicitudes. Intenta de nuevo en ${result.retryAfter} segundos.`,
    }
  }

  return { success: true, headers }
}

// Helper para obtener identificador del request
export function getRateLimitIdentifier(request: Request, userId?: string): string {
  // Priorizar userId si está disponible
  if (userId) {
    return `user:${userId}`
  }

  // Si no, usar IP o combinación de headers
  const forwarded = request.headers.get('x-forwarded-for')
  const realIp = request.headers.get('x-real-ip')
  const ip = forwarded?.split(',')[0]?.trim() || realIp || 'unknown'

  return `ip:${ip}`
}

// Tipos de rate limiting para uso con checkRateLimit
export type RateLimitType = keyof typeof rateLimitConfigs
